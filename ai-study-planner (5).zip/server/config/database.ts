import fs from 'fs';
import path from 'path';
import mysql from 'mysql2/promise';
import bcrypt from 'bcryptjs';

// Types representing database rows
export interface UserRow {
  id: number;
  name: string;
  email: string;
  password: string;
  course: string;
  created_at: string;
}

export interface SubjectRow {
  id: number;
  user_id: number;
  name: string;
  code: string | null;
  description: string | null;
  color: string;
  created_at: string;
}

export interface TaskRow {
  id: number;
  user_id: number;
  subject_id: number;
  title: string;
  description: string | null;
  priority: 'High' | 'Medium' | 'Low';
  status: 'Pending' | 'In Progress' | 'Completed';
  start_date: string;
  deadline: string;
  estimated_hours: number;
  created_at: string;
  updated_at: string;
  subject_name?: string;
  subject_color?: string;
  subject_code?: string;
}

interface LocalDBData {
  users: UserRow[];
  subjects: SubjectRow[];
  tasks: TaskRow[];
  nextIds: {
    users: number;
    subjects: number;
    tasks: number;
  };
}

class DatabaseService {
  private pool: mysql.Pool | null = null;
  private isMySqlConnected = false;
  private localDbPath = path.resolve(process.cwd(), '.study_planner_db.json');
  private localData: LocalDBData = {
    users: [],
    subjects: [],
    tasks: [],
    nextIds: { users: 10, subjects: 20, tasks: 50 },
  };

  constructor() {
    this.initDatabase();
  }

  private async initDatabase() {
    // Attempt MySQL connection if credentials supplied
    const host = process.env.DB_HOST || 'localhost';
    const port = Number(process.env.DB_PORT) || 3306;
    const user = process.env.DB_USER || 'root';
    const password = process.env.DB_PASSWORD || '';
    const database = process.env.DB_NAME || 'ai_study_planner';

    try {
      const tempPool = mysql.createPool({
        host,
        port,
        user,
        password,
        database,
        waitForConnections: true,
        connectionLimit: 10,
        queueLimit: 0,
        connectTimeout: 2000,
      });

      // Quick test ping
      const connection = await tempPool.getConnection();
      await connection.ping();
      connection.release();

      this.pool = tempPool;
      this.isMySqlConnected = true;
      console.log(`[Database] Successfully connected to MySQL database: "${database}" on ${host}:${port}`);
    } catch (err: any) {
      this.isMySqlConnected = false;
      this.pool = null;
      console.log(
        `[Database] Notice: MySQL not reachable on ${host}:${port} (${err.message || 'connection failed'}). Using embedded relational persistent engine with full SQL table parity.`
      );
      this.loadLocalData();
    }
  }

  private getFormattedDate(offsetDays: number = 0): string {
    const d = new Date();
    d.setDate(d.getDate() + offsetDays);
    return d.toISOString().split('T')[0];
  }

  private loadLocalData() {
    if (fs.existsSync(this.localDbPath)) {
      try {
        const fileContent = fs.readFileSync(this.localDbPath, 'utf8');
        this.localData = JSON.parse(fileContent);
        if (this.localData.users.length > 0) return;
      } catch (e) {
        console.error('[Database] Error reading local db file, seeding fresh demo data.');
      }
    }
    this.seedDefaultData();
  }

  private saveLocalData() {
    try {
      fs.writeFileSync(this.localDbPath, JSON.stringify(this.localData, null, 2), 'utf8');
    } catch (err) {
      console.error('[Database] Failed to write to local db file:', err);
    }
  }

  public seedDefaultData() {
    const hashedPassword = bcrypt.hashSync('password123', 10);
    const now = new Date().toISOString();

    const defaultUser: UserRow = {
      id: 1,
      name: 'Rahul Sharma',
      email: 'rahul.sharma@bca.edu',
      password: hashedPassword,
      course: 'BCA 3rd Year',
      created_at: now,
    };

    const defaultSubjects: SubjectRow[] = [
      {
        id: 1,
        user_id: 1,
        name: 'Java Programming',
        code: 'BCA-301',
        description: 'Core Object-Oriented Programming, Multithreading, and Collections Framework',
        color: '#3b82f6',
        created_at: now,
      },
      {
        id: 2,
        user_id: 1,
        name: 'Database Management System',
        code: 'BCA-302',
        description: 'Relational database design, SQL queries, Normalization, and ACID Transactions',
        color: '#10b981',
        created_at: now,
      },
      {
        id: 3,
        user_id: 1,
        name: 'Web Development',
        code: 'BCA-303',
        description: 'HTML5, CSS3, JavaScript, React, and Backend REST APIs',
        color: '#8b5cf6',
        created_at: now,
      },
      {
        id: 4,
        user_id: 1,
        name: 'Computer Networks',
        code: 'BCA-304',
        description: 'OSI 7-Layer Architecture, TCP/IP, IP Addressing, and Subnetting',
        color: '#f59e0b',
        created_at: now,
      },
      {
        id: 5,
        user_id: 1,
        name: 'Python Programming',
        code: 'BCA-305',
        description: 'Data structures, NumPy, Pandas, and Scripting essentials',
        color: '#ef4444',
        created_at: now,
      },
    ];

    const defaultTasks: TaskRow[] = [
      {
        id: 1,
        user_id: 1,
        subject_id: 1,
        title: 'Implement OOP Inheritance and Polymorphism',
        description: 'Create class hierarchy for Employee Management System with method overriding.',
        priority: 'High',
        status: 'Completed',
        start_date: this.getFormattedDate(-5),
        deadline: this.getFormattedDate(-2),
        estimated_hours: 3.5,
        created_at: now,
        updated_at: now,
      },
      {
        id: 2,
        user_id: 1,
        subject_id: 1,
        title: 'Java Exception Handling & Custom Exceptions',
        description: 'Prepare laboratory program for user-defined InvalidAgeException with try-catch-finally block.',
        priority: 'Medium',
        status: 'In Progress',
        start_date: this.getFormattedDate(-2),
        deadline: this.getFormattedDate(1), // due tomorrow
        estimated_hours: 2.0,
        created_at: now,
        updated_at: now,
      },
      {
        id: 3,
        user_id: 1,
        subject_id: 1,
        title: 'Collections Framework Practice (ArrayList & HashMap)',
        description: 'Solve 10 problems on HashMap and ArrayList sorting using Comparator.',
        priority: 'Medium',
        status: 'Pending',
        start_date: this.getFormattedDate(0),
        deadline: this.getFormattedDate(3),
        estimated_hours: 4.0,
        created_at: now,
        updated_at: now,
      },
      {
        id: 4,
        user_id: 1,
        subject_id: 2,
        title: 'Database Normalization (1NF, 2NF, 3NF, BCNF)',
        description: 'Revise normalization rules with practical student-course anomaly examples for viva.',
        priority: 'High',
        status: 'In Progress',
        start_date: this.getFormattedDate(-1),
        deadline: this.getFormattedDate(1), // due tomorrow
        estimated_hours: 3.0,
        created_at: now,
        updated_at: now,
      },
      {
        id: 5,
        user_id: 1,
        subject_id: 2,
        title: 'Complex SQL Queries with JOINs and Subqueries',
        description: 'Write and test INNER, LEFT, RIGHT, and FULL OUTER JOINs with GROUP BY on sample tables.',
        priority: 'High',
        status: 'Completed',
        start_date: this.getFormattedDate(-6),
        deadline: this.getFormattedDate(-3),
        estimated_hours: 4.0,
        created_at: now,
        updated_at: now,
      },
      {
        id: 6,
        user_id: 1,
        subject_id: 2,
        title: 'ACID Properties and Transaction Concurrency',
        description: 'Read notes on Atomicity, Consistency, Isolation, Durability and lock protocols.',
        priority: 'Low',
        status: 'Pending',
        start_date: this.getFormattedDate(1),
        deadline: this.getFormattedDate(5),
        estimated_hours: 2.5,
        created_at: now,
        updated_at: now,
      },
      {
        id: 7,
        user_id: 1,
        subject_id: 3,
        title: 'Build Responsive Navigation and Flexbox Layout',
        description: 'Create mobile-friendly student portal landing screen with Tailwind CSS.',
        priority: 'Medium',
        status: 'Completed',
        start_date: this.getFormattedDate(-4),
        deadline: this.getFormattedDate(-1),
        estimated_hours: 3.0,
        created_at: now,
        updated_at: now,
      },
      {
        id: 8,
        user_id: 1,
        subject_id: 3,
        title: 'Create REST API with Express and Node.js',
        description: 'Implement CRUD routes for study tasks and connect to database with parameterized queries.',
        priority: 'High',
        status: 'Completed',
        start_date: this.getFormattedDate(-3),
        deadline: this.getFormattedDate(0),
        estimated_hours: 5.0,
        created_at: now,
        updated_at: now,
      },
      {
        id: 9,
        user_id: 1,
        subject_id: 3,
        title: 'Implement JWT Authentication & Protected Routes',
        description: 'Add token generation on login and auth middleware for protected endpoints.',
        priority: 'High',
        status: 'In Progress',
        start_date: this.getFormattedDate(-1),
        deadline: this.getFormattedDate(2),
        estimated_hours: 4.0,
        created_at: now,
        updated_at: now,
      },
      {
        id: 10,
        user_id: 1,
        subject_id: 4,
        title: 'OSI vs TCP/IP Layer Comparison Chart',
        description: 'Draw and memorize functions and protocols for each of the 7 OSI layers.',
        priority: 'High',
        status: 'Pending',
        start_date: this.getFormattedDate(-4),
        deadline: this.getFormattedDate(-1), // overdue!
        estimated_hours: 2.0,
        created_at: now,
        updated_at: now,
      },
      {
        id: 11,
        user_id: 1,
        subject_id: 4,
        title: 'Subnetting and IPv4 Addressing Calculation',
        description: 'Practice Class C subnet mask calculation with CIDR notation for 4 subnets.',
        priority: 'Medium',
        status: 'Pending',
        start_date: this.getFormattedDate(0),
        deadline: this.getFormattedDate(0), // due today!
        estimated_hours: 3.0,
        created_at: now,
        updated_at: now,
      },
      {
        id: 12,
        user_id: 1,
        subject_id: 5,
        title: 'Python List Comprehensions & Lambdas',
        description: 'Practice one-line data transformations and filtering exercises.',
        priority: 'Low',
        status: 'Completed',
        start_date: this.getFormattedDate(-7),
        deadline: this.getFormattedDate(-4),
        estimated_hours: 2.0,
        created_at: now,
        updated_at: now,
      },
      {
        id: 13,
        user_id: 1,
        subject_id: 5,
        title: 'NumPy Array Operations and Reshaping',
        description: 'Solve assignment on 2D arrays, matrix multiplication, and slicing.',
        priority: 'Medium',
        status: 'Pending',
        start_date: this.getFormattedDate(2),
        deadline: this.getFormattedDate(6),
        estimated_hours: 3.5,
        created_at: now,
        updated_at: now,
      },
    ];

    this.localData = {
      users: [defaultUser],
      subjects: defaultSubjects,
      tasks: defaultTasks,
      nextIds: { users: 2, subjects: 6, tasks: 14 },
    };
    this.saveLocalData();
  }

  public isUsingMySql(): boolean {
    return this.isMySqlConnected;
  }

  // ===================== USER METHODS =====================
  public async getUserByEmail(email: string): Promise<UserRow | null> {
    const cleanEmail = email.trim().toLowerCase();
    if (this.isMySqlConnected && this.pool) {
      const [rows] = await this.pool.execute<any[]>(
        'SELECT * FROM users WHERE LOWER(email) = ? LIMIT 1',
        [cleanEmail]
      );
      return rows[0] || null;
    }
    const user = this.localData.users.find((u) => u.email.toLowerCase() === cleanEmail);
    return user ? { ...user } : null;
  }

  public async getUserById(id: number): Promise<UserRow | null> {
    if (this.isMySqlConnected && this.pool) {
      const [rows] = await this.pool.execute<any[]>(
        'SELECT id, name, email, course, created_at FROM users WHERE id = ? LIMIT 1',
        [id]
      );
      return rows[0] || null;
    }
    const user = this.localData.users.find((u) => u.id === id);
    if (!user) return null;
    const { password, ...safeUser } = user;
    return safeUser as UserRow;
  }

  public async createUser(name: string, email: string, passwordHash: string, course: string = 'BCA 3rd Year'): Promise<UserRow> {
    const cleanEmail = email.trim().toLowerCase();
    const cleanName = name.trim();
    const now = new Date().toISOString();

    if (this.isMySqlConnected && this.pool) {
      const [result]: any = await this.pool.execute(
        'INSERT INTO users (name, email, password, course, created_at) VALUES (?, ?, ?, ?, NOW())',
        [cleanName, cleanEmail, passwordHash, course]
      );
      const insertedId = result.insertId;
      return {
        id: insertedId,
        name: cleanName,
        email: cleanEmail,
        password: passwordHash,
        course,
        created_at: now,
      };
    }

    const newUser: UserRow = {
      id: this.localData.nextIds.users++,
      name: cleanName,
      email: cleanEmail,
      password: passwordHash,
      course,
      created_at: now,
    };
    this.localData.users.push(newUser);

    // Give new user 3 default BCA subjects to start easily
    const initialSubjects: SubjectRow[] = [
      {
        id: this.localData.nextIds.subjects++,
        user_id: newUser.id,
        name: 'Java Programming',
        code: 'BCA-301',
        description: 'Core OOP, Collections, Multithreading',
        color: '#3b82f6',
        created_at: now,
      },
      {
        id: this.localData.nextIds.subjects++,
        user_id: newUser.id,
        name: 'Database Management System',
        code: 'BCA-302',
        description: 'SQL queries, Normalization, Transactions',
        color: '#10b981',
        created_at: now,
      },
      {
        id: this.localData.nextIds.subjects++,
        user_id: newUser.id,
        name: 'Web Development',
        code: 'BCA-303',
        description: 'Frontend and REST API integration',
        color: '#8b5cf6',
        created_at: now,
      },
    ];
    this.localData.subjects.push(...initialSubjects);

    this.saveLocalData();
    return newUser;
  }

  // ===================== SUBJECT METHODS =====================
  public async getSubjectsByUser(userId: number): Promise<SubjectRow[]> {
    if (this.isMySqlConnected && this.pool) {
      const [rows] = await this.pool.execute<any[]>(
        'SELECT * FROM subjects WHERE user_id = ? ORDER BY name ASC',
        [userId]
      );
      return rows;
    }
    return this.localData.subjects
      .filter((s) => s.user_id === userId)
      .sort((a, b) => a.name.localeCompare(b.name));
  }

  public async getSubjectById(subjectId: number, userId: number): Promise<SubjectRow | null> {
    if (this.isMySqlConnected && this.pool) {
      const [rows] = await this.pool.execute<any[]>(
        'SELECT * FROM subjects WHERE id = ? AND user_id = ? LIMIT 1',
        [subjectId, userId]
      );
      return rows[0] || null;
    }
    return this.localData.subjects.find((s) => s.id === subjectId && s.user_id === userId) || null;
  }

  public async createSubject(userId: number, name: string, code: string | null, description: string | null, color: string): Promise<SubjectRow> {
    const now = new Date().toISOString();
    if (this.isMySqlConnected && this.pool) {
      const [result]: any = await this.pool.execute(
        'INSERT INTO subjects (user_id, name, code, description, color, created_at) VALUES (?, ?, ?, ?, ?, NOW())',
        [userId, name.trim(), code ? code.trim() : null, description ? description.trim() : null, color || '#3b82f6']
      );
      return {
        id: result.insertId,
        user_id: userId,
        name: name.trim(),
        code: code ? code.trim() : null,
        description: description ? description.trim() : null,
        color: color || '#3b82f6',
        created_at: now,
      };
    }

    const newSubject: SubjectRow = {
      id: this.localData.nextIds.subjects++,
      user_id: userId,
      name: name.trim(),
      code: code ? code.trim() : null,
      description: description ? description.trim() : null,
      color: color || '#3b82f6',
      created_at: now,
    };
    this.localData.subjects.push(newSubject);
    this.saveLocalData();
    return newSubject;
  }

  public async updateSubject(subjectId: number, userId: number, name: string, code: string | null, description: string | null, color: string): Promise<SubjectRow | null> {
    if (this.isMySqlConnected && this.pool) {
      const [result]: any = await this.pool.execute(
        'UPDATE subjects SET name = ?, code = ?, description = ?, color = ? WHERE id = ? AND user_id = ?',
        [name.trim(), code ? code.trim() : null, description ? description.trim() : null, color, subjectId, userId]
      );
      if (result.affectedRows === 0) return null;
      return this.getSubjectById(subjectId, userId);
    }

    const index = this.localData.subjects.findIndex((s) => s.id === subjectId && s.user_id === userId);
    if (index === -1) return null;

    this.localData.subjects[index] = {
      ...this.localData.subjects[index],
      name: name.trim(),
      code: code ? code.trim() : null,
      description: description ? description.trim() : null,
      color: color || this.localData.subjects[index].color,
    };
    this.saveLocalData();
    return this.localData.subjects[index];
  }

  public async deleteSubject(subjectId: number, userId: number): Promise<boolean> {
    if (this.isMySqlConnected && this.pool) {
      const [result]: any = await this.pool.execute(
        'DELETE FROM subjects WHERE id = ? AND user_id = ?',
        [subjectId, userId]
      );
      return result.affectedRows > 0;
    }

    const initialLen = this.localData.subjects.length;
    this.localData.subjects = this.localData.subjects.filter((s) => !(s.id === subjectId && s.user_id === userId));
    // Cascade delete associated tasks
    this.localData.tasks = this.localData.tasks.filter((t) => !(t.subject_id === subjectId && t.user_id === userId));
    this.saveLocalData();
    return this.localData.subjects.length < initialLen;
  }

  // ===================== TASK METHODS =====================
  public async getTasksByUser(userId: number): Promise<TaskRow[]> {
    if (this.isMySqlConnected && this.pool) {
      const query = `
        SELECT t.*, s.name as subject_name, s.color as subject_color, s.code as subject_code
        FROM tasks t
        JOIN subjects s ON t.subject_id = s.id
        WHERE t.user_id = ?
        ORDER BY t.deadline ASC, FIELD(t.priority, 'High', 'Medium', 'Low')
      `;
      const [rows] = await this.pool.execute<any[]>(query, [userId]);
      return rows;
    }

    const userSubjects = new Map(this.localData.subjects.map((s) => [s.id, s]));
    const tasks = this.localData.tasks
      .filter((t) => t.user_id === userId)
      .map((t) => {
        const sub = userSubjects.get(t.subject_id);
        return {
          ...t,
          subject_name: sub ? sub.name : 'Unknown Subject',
          subject_color: sub ? sub.color : '#6b7280',
          subject_code: sub ? sub.code || '' : '',
        };
      });

    return tasks.sort((a, b) => new Date(a.deadline).getTime() - new Date(b.deadline).getTime());
  }

  public async getTaskById(taskId: number, userId: number): Promise<TaskRow | null> {
    if (this.isMySqlConnected && this.pool) {
      const query = `
        SELECT t.*, s.name as subject_name, s.color as subject_color, s.code as subject_code
        FROM tasks t
        JOIN subjects s ON t.subject_id = s.id
        WHERE t.id = ? AND t.user_id = ?
        LIMIT 1
      `;
      const [rows] = await this.pool.execute<any[]>(query, [taskId, userId]);
      return rows[0] || null;
    }

    const task = this.localData.tasks.find((t) => t.id === taskId && t.user_id === userId);
    if (!task) return null;
    const sub = this.localData.subjects.find((s) => s.id === task.subject_id);
    return {
      ...task,
      subject_name: sub ? sub.name : 'Unknown Subject',
      subject_color: sub ? sub.color : '#6b7280',
      subject_code: sub ? sub.code || '' : '',
    };
  }

  public async createTask(
    userId: number,
    subjectId: number,
    title: string,
    description: string | null,
    priority: 'High' | 'Medium' | 'Low',
    status: 'Pending' | 'In Progress' | 'Completed',
    startDate: string,
    deadline: string,
    estimatedHours: number
  ): Promise<TaskRow> {
    const now = new Date().toISOString();
    const hours = Number(estimatedHours) || 2;

    if (this.isMySqlConnected && this.pool) {
      const [result]: any = await this.pool.execute(
        `INSERT INTO tasks (user_id, subject_id, title, description, priority, status, start_date, deadline, estimated_hours, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), NOW())`,
        [userId, subjectId, title.trim(), description ? description.trim() : null, priority, status, startDate, deadline, hours]
      );
      const inserted = await this.getTaskById(result.insertId, userId);
      return inserted!;
    }

    const newTask: TaskRow = {
      id: this.localData.nextIds.tasks++,
      user_id: userId,
      subject_id: subjectId,
      title: title.trim(),
      description: description ? description.trim() : null,
      priority,
      status,
      start_date: startDate,
      deadline,
      estimated_hours: hours,
      created_at: now,
      updated_at: now,
    };
    this.localData.tasks.push(newTask);
    this.saveLocalData();

    const sub = this.localData.subjects.find((s) => s.id === subjectId);
    return {
      ...newTask,
      subject_name: sub ? sub.name : '',
      subject_color: sub ? sub.color : '#6b7280',
      subject_code: sub ? sub.code || '' : '',
    };
  }

  public async updateTask(
    taskId: number,
    userId: number,
    subjectId: number,
    title: string,
    description: string | null,
    priority: 'High' | 'Medium' | 'Low',
    status: 'Pending' | 'In Progress' | 'Completed',
    startDate: string,
    deadline: string,
    estimatedHours: number
  ): Promise<TaskRow | null> {
    const now = new Date().toISOString();
    const hours = Number(estimatedHours) || 2;

    if (this.isMySqlConnected && this.pool) {
      const [result]: any = await this.pool.execute(
        `UPDATE tasks 
         SET subject_id = ?, title = ?, description = ?, priority = ?, status = ?, start_date = ?, deadline = ?, estimated_hours = ?, updated_at = NOW()
         WHERE id = ? AND user_id = ?`,
        [subjectId, title.trim(), description ? description.trim() : null, priority, status, startDate, deadline, hours, taskId, userId]
      );
      if (result.affectedRows === 0) return null;
      return this.getTaskById(taskId, userId);
    }

    const index = this.localData.tasks.findIndex((t) => t.id === taskId && t.user_id === userId);
    if (index === -1) return null;

    this.localData.tasks[index] = {
      ...this.localData.tasks[index],
      subject_id: subjectId,
      title: title.trim(),
      description: description ? description.trim() : null,
      priority,
      status,
      start_date: startDate,
      deadline,
      estimated_hours: hours,
      updated_at: now,
    };
    this.saveLocalData();
    return this.getTaskById(taskId, userId);
  }

  public async updateTaskStatus(
    taskId: number,
    userId: number,
    status: 'Pending' | 'In Progress' | 'Completed'
  ): Promise<TaskRow | null> {
    const now = new Date().toISOString();

    if (this.isMySqlConnected && this.pool) {
      const [result]: any = await this.pool.execute(
        'UPDATE tasks SET status = ?, updated_at = NOW() WHERE id = ? AND user_id = ?',
        [status, taskId, userId]
      );
      if (result.affectedRows === 0) return null;
      return this.getTaskById(taskId, userId);
    }

    const task = this.localData.tasks.find((t) => t.id === taskId && t.user_id === userId);
    if (!task) return null;

    task.status = status;
    task.updated_at = now;
    this.saveLocalData();
    return this.getTaskById(taskId, userId);
  }

  public async deleteTask(taskId: number, userId: number): Promise<boolean> {
    if (this.isMySqlConnected && this.pool) {
      const [result]: any = await this.pool.execute(
        'DELETE FROM tasks WHERE id = ? AND user_id = ?',
        [taskId, userId]
      );
      return result.affectedRows > 0;
    }

    const initialLen = this.localData.tasks.length;
    this.localData.tasks = this.localData.tasks.filter((t) => !(t.id === taskId && t.user_id === userId));
    this.saveLocalData();
    return this.localData.tasks.length < initialLen;
  }
}

export const db = new DatabaseService();
