import { Response } from 'express';
import { db } from '../config/database.js';
import { AuthRequest } from '../middleware/auth.js';

export const getTasks = async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const userId = req.user!.id;
    let tasks = await db.getTasksByUser(userId);

    // Optional query filtering
    const { subjectId, priority, status, search, deadlineStatus } = req.query;

    if (subjectId) {
      const sId = parseInt(subjectId as string, 10);
      if (!isNaN(sId)) {
        tasks = tasks.filter((t) => t.subject_id === sId);
      }
    }

    if (priority && ['High', 'Medium', 'Low'].includes(priority as string)) {
      tasks = tasks.filter((t) => t.priority === priority);
    }

    if (status && ['Pending', 'In Progress', 'Completed'].includes(status as string)) {
      tasks = tasks.filter((t) => t.status === status);
    }

    if (search && typeof search === 'string') {
      const q = search.toLowerCase().trim();
      tasks = tasks.filter(
        (t) =>
          t.title.toLowerCase().includes(q) ||
          (t.description && t.description.toLowerCase().includes(q)) ||
          (t.subject_name && t.subject_name.toLowerCase().includes(q))
      );
    }

    if (deadlineStatus && typeof deadlineStatus === 'string') {
      const todayStr = new Date().toISOString().split('T')[0];
      const tomorrow = new Date();
      tomorrow.setDate(tomorrow.getDate() + 1);
      const tomorrowStr = tomorrow.toISOString().split('T')[0];

      if (deadlineStatus === 'overdue') {
        tasks = tasks.filter((t) => t.deadline < todayStr && t.status !== 'Completed');
      } else if (deadlineStatus === 'today') {
        tasks = tasks.filter((t) => t.deadline === todayStr);
      } else if (deadlineStatus === 'tomorrow') {
        tasks = tasks.filter((t) => t.deadline === tomorrowStr);
      } else if (deadlineStatus === 'upcoming') {
        tasks = tasks.filter((t) => t.deadline >= todayStr);
      }
    }

    res.status(200).json({ success: true, count: tasks.length, tasks });
  } catch (error: any) {
    console.error('getTasks Error:', error);
    res.status(500).json({ success: false, message: 'Failed to retrieve study tasks.' });
  }
};

export const getTaskById = async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const userId = req.user!.id;
    const taskId = parseInt(req.params.id, 10);

    if (isNaN(taskId)) {
      res.status(400).json({ success: false, message: 'Invalid task ID.' });
      return;
    }

    const task = await db.getTaskById(taskId, userId);
    if (!task) {
      res.status(404).json({ success: false, message: 'Task not found or access denied.' });
      return;
    }

    res.status(200).json({ success: true, task });
  } catch (error: any) {
    console.error('getTaskById Error:', error);
    res.status(500).json({ success: false, message: 'Failed to retrieve task.' });
  }
};

export const createTask = async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const userId = req.user!.id;
    const {
      subject_id,
      title,
      description,
      priority,
      status,
      start_date,
      deadline,
      estimated_hours,
    } = req.body;

    if (!title || !title.trim()) {
      res.status(400).json({ success: false, message: 'Task title is required.' });
      return;
    }

    const subjectIdNum = parseInt(subject_id, 10);
    if (isNaN(subjectIdNum)) {
      res.status(400).json({ success: false, message: 'Valid subject selection is required.' });
      return;
    }

    // Verify subject belongs to user
    const subject = await db.getSubjectById(subjectIdNum, userId);
    if (!subject) {
      res.status(400).json({ success: false, message: 'Selected subject does not exist or does not belong to you.' });
      return;
    }

    const validPriority = ['High', 'Medium', 'Low'].includes(priority) ? priority : 'Medium';
    const validStatus = ['Pending', 'In Progress', 'Completed'].includes(status) ? status : 'Pending';

    const todayStr = new Date().toISOString().split('T')[0];
    const sDate = start_date || todayStr;
    const dDate = deadline || sDate;
    const hours = Math.max(0.5, Math.min(24, parseFloat(estimated_hours) || 2.0));

    const newTask = await db.createTask(
      userId,
      subjectIdNum,
      title.trim(),
      description ? description.trim() : null,
      validPriority,
      validStatus,
      sDate,
      dDate,
      hours
    );

    res.status(201).json({
      success: true,
      message: 'Study task created successfully!',
      task: newTask,
    });
  } catch (error: any) {
    console.error('createTask Error:', error);
    res.status(500).json({ success: false, message: 'Failed to create study task.' });
  }
};

export const updateTask = async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const userId = req.user!.id;
    const taskId = parseInt(req.params.id, 10);

    if (isNaN(taskId)) {
      res.status(400).json({ success: false, message: 'Invalid task ID.' });
      return;
    }

    const {
      subject_id,
      title,
      description,
      priority,
      status,
      start_date,
      deadline,
      estimated_hours,
    } = req.body;

    if (!title || !title.trim()) {
      res.status(400).json({ success: false, message: 'Task title is required.' });
      return;
    }

    const subjectIdNum = parseInt(subject_id, 10);
    if (isNaN(subjectIdNum)) {
      res.status(400).json({ success: false, message: 'Valid subject selection is required.' });
      return;
    }

    const subject = await db.getSubjectById(subjectIdNum, userId);
    if (!subject) {
      res.status(400).json({ success: false, message: 'Selected subject does not exist or does not belong to you.' });
      return;
    }

    const validPriority = ['High', 'Medium', 'Low'].includes(priority) ? priority : 'Medium';
    const validStatus = ['Pending', 'In Progress', 'Completed'].includes(status) ? status : 'Pending';
    const hours = Math.max(0.5, Math.min(24, parseFloat(estimated_hours) || 2.0));

    const updatedTask = await db.updateTask(
      taskId,
      userId,
      subjectIdNum,
      title.trim(),
      description ? description.trim() : null,
      validPriority,
      validStatus,
      start_date,
      deadline,
      hours
    );

    if (!updatedTask) {
      res.status(404).json({ success: false, message: 'Task not found or access denied.' });
      return;
    }

    res.status(200).json({
      success: true,
      message: 'Study task updated successfully!',
      task: updatedTask,
    });
  } catch (error: any) {
    console.error('updateTask Error:', error);
    res.status(500).json({ success: false, message: 'Failed to update study task.' });
  }
};

export const updateTaskStatus = async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const userId = req.user!.id;
    const taskId = parseInt(req.params.id, 10);
    const { status } = req.body;

    if (isNaN(taskId)) {
      res.status(400).json({ success: false, message: 'Invalid task ID.' });
      return;
    }

    if (!['Pending', 'In Progress', 'Completed'].includes(status)) {
      res.status(400).json({
        success: false,
        message: "Status must be 'Pending', 'In Progress', or 'Completed'.",
      });
      return;
    }

    const updated = await db.updateTaskStatus(taskId, userId, status);
    if (!updated) {
      res.status(404).json({ success: false, message: 'Task not found or access denied.' });
      return;
    }

    res.status(200).json({
      success: true,
      message: `Task status updated to "${status}".`,
      task: updated,
    });
  } catch (error: any) {
    console.error('updateTaskStatus Error:', error);
    res.status(500).json({ success: false, message: 'Failed to update task status.' });
  }
};

export const deleteTask = async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const userId = req.user!.id;
    const taskId = parseInt(req.params.id, 10);

    if (isNaN(taskId)) {
      res.status(400).json({ success: false, message: 'Invalid task ID.' });
      return;
    }

    const deleted = await db.deleteTask(taskId, userId);
    if (!deleted) {
      res.status(404).json({ success: false, message: 'Task not found or access denied.' });
      return;
    }

    res.status(200).json({
      success: true,
      message: 'Study task deleted successfully.',
    });
  } catch (error: any) {
    console.error('deleteTask Error:', error);
    res.status(500).json({ success: false, message: 'Failed to delete task.' });
  }
};
