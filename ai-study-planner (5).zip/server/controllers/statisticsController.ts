import { Response } from 'express';
import { db } from '../config/database.js';
import { AuthRequest } from '../middleware/auth.js';

export const getStatistics = async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const userId = req.user!.id;
    const [tasks, subjects] = await Promise.all([
      db.getTasksByUser(userId),
      db.getSubjectsByUser(userId),
    ]);

    const todayStr = new Date().toISOString().split('T')[0];
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    const tomorrowStr = tomorrow.toISOString().split('T')[0];

    let completed = 0;
    let inProgress = 0;
    let pending = 0;
    let overdue = 0;
    let dueToday = 0;
    let dueTomorrow = 0;
    let upcoming = 0;

    let highPriority = 0;
    let mediumPriority = 0;
    let lowPriority = 0;

    let totalHours = 0;
    let completedHours = 0;
    let pendingHours = 0;

    const subjectStatsMap = new Map<
      number,
      {
        id: number;
        name: string;
        code: string | null;
        color: string;
        total: number;
        completed: number;
        inProgress: number;
        pending: number;
        overdue: number;
        hours: number;
      }
    >();

    subjects.forEach((s) => {
      subjectStatsMap.set(s.id, {
        id: s.id,
        name: s.name,
        code: s.code,
        color: s.color,
        total: 0,
        completed: 0,
        inProgress: 0,
        pending: 0,
        overdue: 0,
        hours: 0,
      });
    });

    tasks.forEach((t) => {
      const hours = Number(t.estimated_hours) || 0;
      totalHours += hours;

      if (t.status === 'Completed') {
        completed++;
        completedHours += hours;
      } else if (t.status === 'In Progress') {
        inProgress++;
        pendingHours += hours;
      } else {
        pending++;
        pendingHours += hours;
      }

      // Overdue check (only if not completed)
      const isTaskOverdue = t.deadline < todayStr && t.status !== 'Completed';
      if (isTaskOverdue) {
        overdue++;
      }

      if (t.deadline === todayStr) {
        dueToday++;
      } else if (t.deadline === tomorrowStr) {
        dueTomorrow++;
      } else if (t.deadline > todayStr) {
        upcoming++;
      }

      if (t.priority === 'High') highPriority++;
      else if (t.priority === 'Medium') mediumPriority++;
      else if (t.priority === 'Low') lowPriority++;

      // Subject stats
      const sStat = subjectStatsMap.get(t.subject_id);
      if (sStat) {
        sStat.total++;
        sStat.hours += hours;
        if (t.status === 'Completed') sStat.completed++;
        else if (t.status === 'In Progress') sStat.inProgress++;
        else sStat.pending++;
        if (isTaskOverdue) sStat.overdue++;
      }
    });

    const totalTasks = tasks.length;
    const completionPercentage = totalTasks > 0 ? Math.round((completed / totalTasks) * 100) : 0;

    const subjectBreakdown = Array.from(subjectStatsMap.values()).map((s) => ({
      ...s,
      completionPercentage: s.total > 0 ? Math.round((s.completed / s.total) * 100) : 0,
    }));

    res.status(200).json({
      success: true,
      statistics: {
        total_subjects: subjects.length,
        total_tasks: totalTasks,
        completed_tasks: completed,
        in_progress_tasks: inProgress,
        pending_tasks: pending,
        overdue_tasks: overdue,
        completion_percentage: completionPercentage,
        priority_breakdown: {
          high: highPriority,
          medium: mediumPriority,
          low: lowPriority,
        },
        deadline_breakdown: {
          overdue,
          due_today: dueToday,
          due_tomorrow: dueTomorrow,
          upcoming,
        },
        hours: {
          total: parseFloat(totalHours.toFixed(1)),
          completed: parseFloat(completedHours.toFixed(1)),
          pending: parseFloat(pendingHours.toFixed(1)),
        },
        subjects: subjectBreakdown,
      },
    });
  } catch (error: any) {
    console.error('getStatistics Error:', error);
    res.status(500).json({ success: false, message: 'Failed to compute study statistics.' });
  }
};
