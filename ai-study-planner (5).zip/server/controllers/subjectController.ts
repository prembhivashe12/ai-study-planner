import { Response } from 'express';
import { db } from '../config/database.js';
import { AuthRequest } from '../middleware/auth.js';

export const getSubjects = async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const userId = req.user!.id;
    const subjects = await db.getSubjectsByUser(userId);
    res.status(200).json({ success: true, subjects });
  } catch (error: any) {
    console.error('getSubjects Error:', error);
    res.status(500).json({ success: false, message: 'Failed to retrieve subjects.' });
  }
};

export const createSubject = async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const userId = req.user!.id;
    const { name, code, description, color } = req.body;

    if (!name || !name.trim()) {
      res.status(400).json({ success: false, message: 'Subject name is required.' });
      return;
    }

    const newSubject = await db.createSubject(
      userId,
      name.trim(),
      code ? code.trim() : null,
      description ? description.trim() : null,
      color || '#3b82f6'
    );

    res.status(201).json({
      success: true,
      message: 'Subject added successfully!',
      subject: newSubject,
    });
  } catch (error: any) {
    console.error('createSubject Error:', error);
    res.status(500).json({ success: false, message: 'Failed to create subject.' });
  }
};

export const updateSubject = async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const userId = req.user!.id;
    const subjectId = parseInt(req.params.id, 10);
    const { name, code, description, color } = req.body;

    if (isNaN(subjectId)) {
      res.status(400).json({ success: false, message: 'Invalid subject ID.' });
      return;
    }

    if (!name || !name.trim()) {
      res.status(400).json({ success: false, message: 'Subject name cannot be empty.' });
      return;
    }

    const updated = await db.updateSubject(
      subjectId,
      userId,
      name.trim(),
      code ? code.trim() : null,
      description ? description.trim() : null,
      color
    );

    if (!updated) {
      res.status(404).json({ success: false, message: 'Subject not found or unauthorized.' });
      return;
    }

    res.status(200).json({
      success: true,
      message: 'Subject updated successfully!',
      subject: updated,
    });
  } catch (error: any) {
    console.error('updateSubject Error:', error);
    res.status(500).json({ success: false, message: 'Failed to update subject.' });
  }
};

export const deleteSubject = async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const userId = req.user!.id;
    const subjectId = parseInt(req.params.id, 10);

    if (isNaN(subjectId)) {
      res.status(400).json({ success: false, message: 'Invalid subject ID.' });
      return;
    }

    const deleted = await db.deleteSubject(subjectId, userId);
    if (!deleted) {
      res.status(404).json({ success: false, message: 'Subject not found or unauthorized.' });
      return;
    }

    res.status(200).json({
      success: true,
      message: 'Subject and its associated study tasks deleted successfully.',
    });
  } catch (error: any) {
    console.error('deleteSubject Error:', error);
    res.status(500).json({ success: false, message: 'Failed to delete subject.' });
  }
};
