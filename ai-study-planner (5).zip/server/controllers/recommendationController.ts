import { Response } from 'express';
import { db } from '../config/database.js';
import { AuthRequest } from '../middleware/auth.js';
import { recommendationService } from '../services/geminiService.js';

export const getRecommendations = async (req: AuthRequest, res: Response): Promise<void> => {
  try {
    const userId = req.user!.id;
    const studentName = req.user!.name || 'Student';

    const [tasks, subjects] = await Promise.all([
      db.getTasksByUser(userId),
      db.getSubjectsByUser(userId),
    ]);

    const result = await recommendationService.generateRecommendations(studentName, tasks, subjects);

    res.status(200).json({
      success: true,
      ...result,
    });
  } catch (error: any) {
    console.error('getRecommendations Error:', error);
    res.status(500).json({ success: false, message: 'Failed to generate study recommendations.' });
  }
};
