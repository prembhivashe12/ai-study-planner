import { Router } from 'express';
import { register, login, logout, getCurrentUser, resetDemoData } from '../controllers/authController.js';
import { authMiddleware } from '../middleware/auth.js';

const router = Router();

router.post('/register', register);
router.post('/login', login);
router.post('/logout', logout);
router.get('/me', authMiddleware, getCurrentUser);
router.post('/reset-demo', authMiddleware, resetDemoData);

export default router;
