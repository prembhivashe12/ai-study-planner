import { Router } from 'express';
import { getStatistics } from '../controllers/statisticsController.js';
import { authMiddleware } from '../middleware/auth.js';

const router = Router();

router.use(authMiddleware);
router.get('/', getStatistics);

export default router;
