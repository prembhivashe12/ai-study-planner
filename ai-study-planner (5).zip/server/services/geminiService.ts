import { GoogleGenAI, Type } from '@google/genai';
import { SubjectRow, TaskRow } from '../config/database.js';

export interface StudyRecommendation {
  id: string;
  category: 'Urgent' | 'Subject Focus' | 'Schedule Optimization' | 'Revision' | 'Wellbeing';
  title: string;
  recommendation: string;
  actionableStep: string;
  priorityLevel: 'High' | 'Medium' | 'Low';
  targetSubject?: string;
  suggestedHours?: number;
}

export interface RecommendationResponse {
  source: 'Gemini AI (gemini-3.8-flash)' | 'Academic Rule-Based Engine (Fallback)';
  generatedAt: string;
  studentSummary: string;
  recommendations: StudyRecommendation[];
  dailyStudyPlan: {
    day: string;
    focusSubject: string;
    targetTasks: string[];
    allocatedHours: number;
  }[];
}

export class RecommendationService {
  private ai: GoogleGenAI | null = null;

  constructor() {
    const apiKey = process.env.GEMINI_API_KEY;
    if (apiKey && apiKey !== 'MY_GEMINI_API_KEY') {
      try {
        this.ai = new GoogleGenAI({
          apiKey,
          httpOptions: {
            headers: {
              'User-Agent': 'aistudio-build',
            },
          },
        });
      } catch (err) {
        console.error('[GeminiService] Failed to initialize GoogleGenAI client:', err);
      }
    }
  }

  public async generateRecommendations(
    studentName: string,
    tasks: TaskRow[],
    subjects: SubjectRow[]
  ): Promise<RecommendationResponse> {
    const todayStr = new Date().toISOString().split('T')[0];
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    const tomorrowStr = tomorrow.toISOString().split('T')[0];

    // Compute task metrics for AI analysis or rule engine
    const overdueTasks = tasks.filter((t) => t.deadline < todayStr && t.status !== 'Completed');
    const dueTodayTasks = tasks.filter((t) => t.deadline === todayStr && t.status !== 'Completed');
    const dueTomorrowTasks = tasks.filter((t) => t.deadline === tomorrowStr && t.status !== 'Completed');
    const highPriorityPending = tasks.filter((t) => t.priority === 'High' && t.status !== 'Completed');
    const completedTasks = tasks.filter((t) => t.status === 'Completed');
    const pendingTasks = tasks.filter((t) => t.status !== 'Completed');

    // Subject breakdown
    const subjectSummary = subjects.map((sub) => {
      const subTasks = tasks.filter((t) => t.subject_id === sub.id);
      const subCompleted = subTasks.filter((t) => t.status === 'Completed').length;
      const subPending = subTasks.filter((t) => t.status !== 'Completed').length;
      const subOverdue = subTasks.filter((t) => t.deadline < todayStr && t.status !== 'Completed').length;
      const totalHours = subTasks.reduce((acc, t) => acc + Number(t.estimated_hours || 0), 0);
      return {
        name: sub.name,
        code: sub.code,
        total: subTasks.length,
        completed: subCompleted,
        pending: subPending,
        overdue: subOverdue,
        totalHours,
      };
    });

    // Try Gemini API if key is present
    if (this.ai) {
      try {
        const prompt = `
You are an expert academic advisor and AI study coach for a 3rd-year Bachelor of Computer Applications (BCA) student named ${studentName}.
Analyze the student's actual current academic workload and produce tailored, actionable study advice.

Today's Date: ${todayStr}
Tomorrow's Date: ${tomorrowStr}

Student Workload Metrics:
- Total Tasks: ${tasks.length}
- Completed Tasks: ${completedTasks.length}
- Pending / In Progress Tasks: ${pendingTasks.length}
- Overdue Tasks: ${overdueTasks.length} (${overdueTasks.map((t) => `"${t.title}" in ${t.subject_name}`).join(', ') || 'None'})
- Due Today Tasks: ${dueTodayTasks.length} (${dueTodayTasks.map((t) => `"${t.title}" in ${t.subject_name}`).join(', ') || 'None'})
- Due Tomorrow Tasks: ${dueTomorrowTasks.length} (${dueTomorrowTasks.map((t) => `"${t.title}" in ${t.subject_name}`).join(', ') || 'None'})
- High-Priority Pending Tasks: ${highPriorityPending.length} (${highPriorityPending.map((t) => `"${t.title}" (${t.subject_name})`).join(', ') || 'None'})

Subject Breakdown:
${subjectSummary.map((s) => `- ${s.name} (${s.code || 'BCA'}): ${s.completed}/${s.total} completed, ${s.pending} pending, ${s.overdue} overdue, ${s.totalHours} hrs estimated`).join('\n')}

Generate:
1. A concise 2-sentence student summary assessing their progress and primary bottleneck.
2. Exactly 4 to 5 high-impact, specific recommendations with:
   - category (Urgent, Subject Focus, Schedule Optimization, Revision, or Wellbeing)
   - title
   - recommendation (Must reference specific subjects like DBMS, Java, or Web Development, their actual deadlines, and realistic study durations like "study DBMS for 2 hours today")
   - actionableStep (one concrete action to do right now)
   - priorityLevel (High, Medium, or Low)
   - targetSubject
   - suggestedHours
3. A 5-day structured study schedule allocating pending tasks into balanced daily slots.
`;

        const response = await this.ai.models.generateContent({
          model: 'gemini-3.8-flash',
          contents: prompt,
          config: {
            responseMimeType: 'application/json',
            responseSchema: {
              type: Type.OBJECT,
              properties: {
                studentSummary: { type: Type.STRING },
                recommendations: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      id: { type: Type.STRING },
                      category: {
                        type: Type.STRING,
                        enum: ['Urgent', 'Subject Focus', 'Schedule Optimization', 'Revision', 'Wellbeing'],
                      },
                      title: { type: Type.STRING },
                      recommendation: { type: Type.STRING },
                      actionableStep: { type: Type.STRING },
                      priorityLevel: { type: Type.STRING, enum: ['High', 'Medium', 'Low'] },
                      targetSubject: { type: Type.STRING },
                      suggestedHours: { type: Type.NUMBER },
                    },
                    required: ['id', 'category', 'title', 'recommendation', 'actionableStep', 'priorityLevel'],
                  },
                },
                dailyStudyPlan: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      day: { type: Type.STRING },
                      focusSubject: { type: Type.STRING },
                      targetTasks: {
                        type: Type.ARRAY,
                        items: { type: Type.STRING },
                      },
                      allocatedHours: { type: Type.NUMBER },
                    },
                    required: ['day', 'focusSubject', 'targetTasks', 'allocatedHours'],
                  },
                },
              },
              required: ['studentSummary', 'recommendations', 'dailyStudyPlan'],
            },
          },
        });

        const parsed = JSON.parse(response.text?.trim() || '{}');
        if (parsed.recommendations && parsed.recommendations.length > 0) {
          return {
            source: 'Gemini AI (gemini-3.8-flash)',
            generatedAt: new Date().toISOString(),
            studentSummary: parsed.studentSummary,
            recommendations: parsed.recommendations,
            dailyStudyPlan: parsed.dailyStudyPlan || [],
          };
        }
      } catch (err) {
        console.warn('[GeminiService] AI generation failed or throttled, using intelligent rule-based engine:', err);
      }
    }

    // High quality Rule-Based Fallback
    return this.generateRuleBasedRecommendations(
      studentName,
      tasks,
      subjects,
      overdueTasks,
      dueTodayTasks,
      dueTomorrowTasks,
      highPriorityPending,
      subjectSummary
    );
  }

  private generateRuleBasedRecommendations(
    studentName: string,
    tasks: TaskRow[],
    subjects: SubjectRow[],
    overdueTasks: TaskRow[],
    dueTodayTasks: TaskRow[],
    dueTomorrowTasks: TaskRow[],
    highPriorityPending: TaskRow[],
    subjectSummary: any[]
  ): RecommendationResponse {
    const recs: StudyRecommendation[] = [];

    // Rule 1: Overdue tasks alert
    if (overdueTasks.length > 0) {
      const topOverdue = overdueTasks[0];
      recs.push({
        id: 'rec-overdue',
        category: 'Urgent',
        title: `Resolve Overdue Task: ${topOverdue.title}`,
        recommendation: `You have an overdue study task in ${topOverdue.subject_name}. Deadlines missed can disrupt your exam revision cycle. Allocate 1.5 - 2 hours today to complete this before moving to new topics.`,
        actionableStep: `Open ${topOverdue.subject_name} syllabus notes and finish "${topOverdue.title}" immediately.`,
        priorityLevel: 'High',
        targetSubject: topOverdue.subject_name,
        suggestedHours: 2.0,
      });
    }

    // Rule 2: Tasks due tomorrow / today
    if (dueTomorrowTasks.length > 0) {
      const dueNext = dueTomorrowTasks[0];
      recs.push({
        id: 'rec-due-tomorrow',
        category: 'Urgent',
        title: `Upcoming Deadline Tomorrow: ${dueNext.subject_name}`,
        recommendation: `You have a high-priority ${dueNext.subject_name} task ("${dueNext.title}") due tomorrow. Consider studying ${dueNext.subject_name} for 2 hours today to avoid last-minute stress.`,
        actionableStep: `Block 2 hours of focused Pomodoro sessions today for "${dueNext.title}".`,
        priorityLevel: 'High',
        targetSubject: dueNext.subject_name,
        suggestedHours: Number(dueNext.estimated_hours) || 2.0,
      });
    } else if (dueTodayTasks.length > 0) {
      const dueNow = dueTodayTasks[0];
      recs.push({
        id: 'rec-due-today',
        category: 'Urgent',
        title: `Task Due Today: ${dueNow.title}`,
        recommendation: `"${dueNow.title}" in ${dueNow.subject_name} is scheduled for today. Complete it during your primary study block to keep your streak intact.`,
        actionableStep: `Review key concepts and mark as Completed upon finishing.`,
        priorityLevel: 'High',
        targetSubject: dueNow.subject_name,
        suggestedHours: Number(dueNow.estimated_hours) || 2.0,
      });
    }

    // Rule 3: High Priority vs Low Priority balance
    if (highPriorityPending.length > 0) {
      const topPriority = highPriorityPending[0];
      recs.push({
        id: 'rec-priority',
        category: 'Subject Focus',
        title: `Tackle High-Priority Concept: ${topPriority.title}`,
        recommendation: `You have critical pending tasks in ${topPriority.subject_name}. Schedule ${topPriority.subject_name} practice before taking on lower-priority elective tasks.`,
        actionableStep: `Focus on problem-solving and coding practice for ${topPriority.subject_name}.`,
        priorityLevel: 'High',
        targetSubject: topPriority.subject_name,
        suggestedHours: Number(topPriority.estimated_hours) || 3.0,
      });
    }

    // Rule 4: Subject workload imbalance check
    // Find subject with most pending tasks vs subject with most completed tasks
    const sortedPending = [...subjectSummary].sort((a, b) => b.pending - a.pending);
    const sortedCompleted = [...subjectSummary].sort((a, b) => b.completed - a.completed);

    if (sortedPending.length > 0 && sortedCompleted.length > 0 && sortedPending[0].pending > 0) {
      const needySubject = sortedPending[0];
      const doneSubject = sortedCompleted[0];

      if (doneSubject.completed > 0 && doneSubject.name !== needySubject.name) {
        recs.push({
          id: 'rec-balance',
          category: 'Schedule Optimization',
          title: `Rebalance Subject Hours: Focus on ${needySubject.name}`,
          recommendation: `You have completed most of your ${doneSubject.name} tasks (${doneSubject.completed} completed). You can now safely divert your focus hours toward ${needySubject.name}, which has ${needySubject.pending} pending tasks.`,
          actionableStep: `Dedicate your next two 45-minute study intervals specifically to ${needySubject.name}.`,
          priorityLevel: 'Medium',
          targetSubject: needySubject.name,
          suggestedHours: 2.5,
        });
      } else {
        recs.push({
          id: 'rec-backlog',
          category: 'Subject Focus',
          title: `Clear Pending Workload in ${needySubject.name}`,
          recommendation: `You have ${needySubject.pending} pending tasks in ${needySubject.name} with roughly ${needySubject.totalHours} estimated study hours required. Create small 30-minute milestones to avoid burnout.`,
          actionableStep: `Break down the largest task into sub-topics and revise key formulas.`,
          priorityLevel: 'Medium',
          targetSubject: needySubject.name,
          suggestedHours: 2.0,
        });
      }
    }

    // Rule 5: Active Recall & Revision recommendation
    recs.push({
      id: 'rec-revision',
      category: 'Revision',
      title: 'BCA Viva & Lab Practical Preparation Strategy',
      recommendation: 'In computer applications courses, theoretical understanding must be coupled with hands-on coding and lab execution. Practice dry-running SQL queries, Java syntax, and network subnetting on paper before practical exams.',
      actionableStep: 'Create a 1-page quick formula & syntax cheat sheet for your upcoming exam.',
      priorityLevel: 'Low',
      suggestedHours: 1.5,
    });

    // 5-day schedule generator
    const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];
    const pendingList = tasks.filter((t) => t.status !== 'Completed');
    const dailyPlan = days.map((day, idx) => {
      const assigned = pendingList[idx % Math.max(1, pendingList.length)];
      return {
        day,
        focusSubject: assigned ? assigned.subject_name || 'Core Programming' : 'Revision & Practice',
        targetTasks: assigned ? [assigned.title] : ['Comprehensive Revision & Previous Year Question Papers'],
        allocatedHours: assigned ? Number(assigned.estimated_hours) || 2 : 2.5,
      };
    });

    const completionRate = tasks.length > 0
      ? Math.round((tasks.filter((t) => t.status === 'Completed').length / tasks.length) * 100)
      : 0;

    return {
      source: 'Academic Rule-Based Engine (Fallback)',
      generatedAt: new Date().toISOString(),
      studentSummary: `${studentName}, you have maintained a ${completionRate}% task completion rate across ${subjects.length} BCA subjects. Focusing on high-priority deadlines will maximize your semester grade.`,
      recommendations: recs,
      dailyStudyPlan: dailyPlan,
    };
  }
}

export const recommendationService = new RecommendationService();
