import React, { createContext, useContext, useState, useEffect } from 'react';
import { User } from '../types/index.js';
import { api, getStoredToken, setStoredToken, removeStoredToken } from '../services/api.js';

interface AuthContextType {
  user: User | null;
  token: string | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  databaseMode: string;
  login: (email: string, pass: string) => Promise<void>;
  register: (name: string, email: string, pass: string, course?: string) => Promise<void>;
  logout: () => void;
  quickDemoLogin: () => Promise<void>;
  reloadUser: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [token, setToken] = useState<string | null>(getStoredToken());
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [databaseMode, setDatabaseMode] = useState<string>('Detecting...');

  const reloadUser = async () => {
    const currentToken = getStoredToken();
    if (!currentToken) {
      setUser(null);
      setIsLoading(false);
      return;
    }

    try {
      const data = await api.auth.getCurrentUser();
      if (data.success && data.user) {
        setUser(data.user);
        setDatabaseMode(data.databaseMode || 'MySQL Server');
      } else {
        removeStoredToken();
        setUser(null);
        setToken(null);
      }
    } catch (err) {
      console.warn('Session expired or invalid token:', err);
      removeStoredToken();
      setUser(null);
      setToken(null);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    reloadUser();
  }, []);

  const login = async (email: string, pass: string) => {
    setIsLoading(true);
    try {
      const res = await api.auth.login({ email, password: pass });
      if (res.success && res.token) {
        setStoredToken(res.token);
        setToken(res.token);
        setUser(res.user);
      }
    } finally {
      setIsLoading(false);
    }
  };

  const register = async (name: string, email: string, pass: string, course?: string) => {
    setIsLoading(true);
    try {
      const res = await api.auth.register({ name, email, password: pass, course });
      if (res.success && res.token) {
        setStoredToken(res.token);
        setToken(res.token);
        setUser(res.user);
      }
    } finally {
      setIsLoading(false);
    }
  };

  const quickDemoLogin = async () => {
    await login('rahul.sharma@bca.edu', 'password123');
  };

  const logout = () => {
    api.auth.logout().catch(() => {});
    removeStoredToken();
    setUser(null);
    setToken(null);
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        token,
        isAuthenticated: !!user,
        isLoading,
        databaseMode,
        login,
        register,
        logout,
        quickDemoLogin,
        reloadUser,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
