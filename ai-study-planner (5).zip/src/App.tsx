import React, { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext.js';
import { Navbar } from './components/Navbar.js';
import { TaskModal } from './components/TaskModal.js';
import { SubjectModal } from './components/SubjectModal.js';
import { DeleteConfirmModal } from './components/DeleteConfirmModal.js';
import { LandingPage } from './pages/LandingPage.js';
import { LoginPage } from './pages/LoginPage.js';
import { RegisterPage } from './pages/RegisterPage.js';
import { DashboardPage } from './pages/DashboardPage.js';
import { SubjectsPage } from './pages/SubjectsPage.js';
import { TasksPage } from './pages/TasksPage.js';
import { SubjectWisePage } from './pages/SubjectWisePage.js';
import { PriorityDeadlinesPage } from './pages/PriorityDeadlinesPage.js';
import { StatisticsPage } from './pages/StatisticsPage.js';
import { RecommendationsPage } from './pages/RecommendationsPage.js';
import { StudyPlanPage } from './pages/StudyPlanPage.js';
import { ProfilePage } from './pages/ProfilePage.js';
import { api } from './services/api.js';
import { Subject, Task, Priority, TaskStatus } from './types/index.js';

function MainApp() {
  const { isAuthenticated, isLoading } = useAuth();
  const [authView, setAuthView] = useState<'landing' | 'login' | 'register'>('landing');
  const [currentTab, setCurrentTab] = useState<string>('dashboard');

  // Global subjects state
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [selectedSubjectPlanId, setSelectedSubjectPlanId] = useState<number | null>(null);

  // Modal States
  const [isTaskModalOpen, setIsTaskModalOpen] = useState(false);
  const [taskToEdit, setTaskToEdit] = useState<Task | null>(null);
  const [presetSubjectId, setPresetSubjectId] = useState<number | undefined>(undefined);

  const [isSubjectModalOpen, setIsSubjectModalOpen] = useState(false);
  const [subjectToEdit, setSubjectToEdit] = useState<Subject | null>(null);

  const [deleteModalState, setDeleteModalState] = useState<{
    isOpen: boolean;
    type: 'task' | 'subject';
    target: Task | Subject | null;
    isDeleting: boolean;
  }>({
    isOpen: false,
    type: 'task',
    target: null,
    isDeleting: false,
  });

  // Global Toast / Notice message
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  const loadGlobalSubjects = async () => {
    try {
      const res = await api.subjects.getAll();
      if (res.success) setSubjects(res.subjects);
    } catch (e) {
      console.error('Failed to load global subjects list:', e);
    }
  };

  useEffect(() => {
    if (isAuthenticated) {
      loadGlobalSubjects();
    }
  }, [isAuthenticated]);

  // Loading spinner during auth check
  if (isLoading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="flex flex-col items-center gap-3">
          <div className="h-10 w-10 border-4 border-indigo-600 border-t-transparent rounded-full animate-spin" />
          <p className="text-xs font-semibold text-slate-500">Loading AI Study Planner...</p>
        </div>
      </div>
    );
  }

  // Not authenticated flows
  if (!isAuthenticated) {
    if (authView === 'login') {
      return (
        <LoginPage
          onNavigateRegister={() => setAuthView('register')}
          onNavigateHome={() => setAuthView('landing')}
        />
      );
    }
    if (authView === 'register') {
      return (
        <RegisterPage
          onNavigateLogin={() => setAuthView('login')}
          onNavigateHome={() => setAuthView('landing')}
        />
      );
    }
    return (
      <LandingPage
        onNavigateLogin={() => setAuthView('login')}
        onNavigateRegister={() => setAuthView('register')}
      />
    );
  }

  // Task actions
  const handleOpenAddTask = (subjectId?: number) => {
    setTaskToEdit(null);
    setPresetSubjectId(subjectId);
    setIsTaskModalOpen(true);
  };

  const handleOpenEditTask = (task: Task) => {
    setTaskToEdit(task);
    setPresetSubjectId(task.subject_id);
    setIsTaskModalOpen(true);
  };

  const handleSaveTask = async (taskData: {
    subject_id: number;
    title: string;
    description: string;
    priority: Priority;
    status: TaskStatus;
    start_date: string;
    deadline: string;
    estimated_hours: number;
  }) => {
    if (taskToEdit) {
      await api.tasks.update(taskToEdit.id, taskData);
      showToast(`Task "${taskData.title}" updated successfully!`);
    } else {
      await api.tasks.create(taskData);
      showToast(`New task "${taskData.title}" added to syllabus!`);
    }
  };

  const handleOpenDeleteTask = (task: Task) => {
    setDeleteModalState({
      isOpen: true,
      type: 'task',
      target: task,
      isDeleting: false,
    });
  };

  // Subject actions
  const handleOpenAddSubject = () => {
    setSubjectToEdit(null);
    setIsSubjectModalOpen(true);
  };

  const handleOpenEditSubject = (subject: Subject) => {
    setSubjectToEdit(subject);
    setIsSubjectModalOpen(true);
  };

  const handleSaveSubject = async (subjectData: {
    name: string;
    code: string;
    description: string;
    color: string;
  }) => {
    if (subjectToEdit) {
      await api.subjects.update(subjectToEdit.id, subjectData);
      showToast(`Subject "${subjectData.name}" updated!`);
    } else {
      await api.subjects.create(subjectData);
      showToast(`Subject "${subjectData.name}" created!`);
    }
    await loadGlobalSubjects();
  };

  const handleOpenDeleteSubject = (subject: Subject) => {
    setDeleteModalState({
      isOpen: true,
      type: 'subject',
      target: subject,
      isDeleting: false,
    });
  };

  // Confirm delete handler
  const handleConfirmDelete = async () => {
    if (!deleteModalState.target) return;
    setDeleteModalState((prev) => ({ ...prev, isDeleting: true }));

    try {
      if (deleteModalState.type === 'task') {
        const t = deleteModalState.target as Task;
        await api.tasks.delete(t.id);
        showToast(`Study task "${t.title}" deleted.`);
      } else {
        const s = deleteModalState.target as Subject;
        await api.subjects.delete(s.id);
        showToast(`Subject "${s.name}" and associated tasks deleted.`);
        await loadGlobalSubjects();
      }
      setDeleteModalState({ isOpen: false, type: 'task', target: null, isDeleting: false });
    } catch (err: any) {
      alert('Delete failed: ' + err.message);
      setDeleteModalState((prev) => ({ ...prev, isDeleting: false }));
    }
  };

  const handleSelectSubjectPlan = (subId: number) => {
    setSelectedSubjectPlanId(subId);
    setCurrentTab('subject-wise');
  };

  return (
    <div className="min-h-screen bg-slate-100/70 text-slate-800 flex flex-col justify-between">
      <div>
        {/* Navigation Bar */}
        <Navbar currentTab={currentTab} onSelectTab={setCurrentTab} />

        {/* Global Toast Notification */}
        {toastMessage && (
          <div className="fixed bottom-6 right-6 z-50 bg-slate-900 text-white text-xs font-semibold px-4 py-3 rounded-2xl shadow-xl border border-slate-700 animate-in fade-in slide-in-from-bottom-5 duration-200">
            {toastMessage}
          </div>
        )}

        {/* Main Content View */}
        <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {currentTab === 'dashboard' && (
            <DashboardPage
              onNavigateTab={setCurrentTab}
              onOpenAddTask={() => handleOpenAddTask()}
              onOpenAddSubject={handleOpenAddSubject}
              onEditTask={handleOpenEditTask}
            />
          )}

          {currentTab === 'subjects' && (
            <SubjectsPage
              onOpenAddSubject={handleOpenAddSubject}
              onEditSubject={handleOpenEditSubject}
              onDeleteSubject={handleOpenDeleteSubject}
              onSelectSubjectPlan={handleSelectSubjectPlan}
            />
          )}

          {currentTab === 'tasks' && (
            <TasksPage
              onOpenAddTask={() => handleOpenAddTask()}
              onEditTask={handleOpenEditTask}
              onDeleteTask={handleOpenDeleteTask}
              subjects={subjects}
            />
          )}

          {currentTab === 'subject-wise' && (
            <SubjectWisePage
              onOpenAddTaskForSubject={(subId) => handleOpenAddTask(subId)}
              onEditTask={handleOpenEditTask}
              initialSelectedSubjectId={selectedSubjectPlanId}
            />
          )}

          {currentTab === 'priority-deadlines' && (
            <PriorityDeadlinesPage onEditTask={handleOpenEditTask} />
          )}

          {currentTab === 'statistics' && <StatisticsPage />}

          {currentTab === 'recommendations' && <RecommendationsPage />}

          {currentTab === 'study-plan' && (
            <StudyPlanPage
              onEditTask={handleOpenEditTask}
              onOpenAddTask={() => handleOpenAddTask()}
            />
          )}

          {currentTab === 'profile' && <ProfilePage />}
        </main>
      </div>

      {/* Footer */}
      <footer className="border-t border-slate-200 bg-white py-4 mt-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-2 text-[11px] text-slate-500">
          <p>
            Problem Statement 16 – AI Study Planner (Feature Set C) • BCA 3rd Year Academic Project
          </p>
          <p className="font-mono text-slate-400">
            Node.js / Express • MySQL Schema • React • Tailwind CSS
          </p>
        </div>
      </footer>

      {/* Global Modals */}
      <TaskModal
        isOpen={isTaskModalOpen}
        onClose={() => setIsTaskModalOpen(false)}
        onSubmit={handleSaveTask}
        taskToEdit={taskToEdit}
        subjects={subjects}
        initialSubjectId={presetSubjectId}
      />

      <SubjectModal
        isOpen={isSubjectModalOpen}
        onClose={() => setIsSubjectModalOpen(false)}
        onSubmit={handleSaveSubject}
        subjectToEdit={subjectToEdit}
      />

      <DeleteConfirmModal
        isOpen={deleteModalState.isOpen}
        onClose={() =>
          setDeleteModalState({ isOpen: false, type: 'task', target: null, isDeleting: false })
        }
        onConfirm={handleConfirmDelete}
        title={
          deleteModalState.type === 'task'
            ? 'Delete Study Task?'
            : 'Delete Academic Subject?'
        }
        message={
          deleteModalState.type === 'task'
            ? `Are you sure you want to permanently delete "${
                (deleteModalState.target as Task)?.title
              }"? This action cannot be undone.`
            : `Are you sure you want to delete "${
                (deleteModalState.target as Subject)?.name
              }"? All study tasks belonging to this subject will also be deleted.`
        }
        isDeleting={deleteModalState.isDeleting}
      />
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <MainApp />
    </AuthProvider>
  );
}
