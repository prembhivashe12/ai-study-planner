import React, { useState, useEffect } from 'react';
import { api } from '../services/api.js';
import { StatisticsData } from '../types/index.js';
import { StatCard } from '../components/StatCard.js';
import { DonutChart, HorizontalBarChart, ProgressBar } from '../components/Charts.js';
import {
  BarChart3,
  CheckCircle2,
  Clock,
  AlertTriangle,
  FolderGit2,
  BookOpen,
  Hourglass,
  Layers,
  Award,
} from 'lucide-react';

export const StatisticsPage: React.FC = () => {
  const [stats, setStats] = useState<StatisticsData | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const loadStats = async () => {
    try {
      setIsLoading(true);
      setError(null);
      const res = await api.statistics.get();
      if (res.success) setStats(res.statistics);
    } catch (err: any) {
      setError(err.message || 'Failed to load progress statistics.');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadStats();
  }, []);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900 flex items-center gap-2">
            <BarChart3 className="h-5 w-5 text-indigo-600" />
            Academic Progress Statistics
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Quantitative analysis of your study progress, completion rate, and workload balance
          </p>
        </div>

        <div className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-indigo-50 border border-indigo-100 text-indigo-700 text-xs font-bold">
          <Award className="h-4 w-4" />
          <span>Semester Completion: {stats?.completion_percentage || 0}%</span>
        </div>
      </div>

      {error && (
        <div className="p-4 bg-red-50 border border-red-200 text-red-700 text-xs rounded-2xl">
          {error}
        </div>
      )}

      {/* Metrics Row */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 sm:gap-4">
        <StatCard
          title="Total Tasks"
          value={stats?.total_tasks || 0}
          subtitle="Syllabus topics"
          icon={BookOpen}
          colorScheme="blue"
        />
        <StatCard
          title="Completed"
          value={stats?.completed_tasks || 0}
          subtitle="Finished"
          icon={CheckCircle2}
          colorScheme="emerald"
        />
        <StatCard
          title="In Progress"
          value={stats?.in_progress_tasks || 0}
          subtitle="Active study"
          icon={Hourglass}
          colorScheme="indigo"
        />
        <StatCard
          title="Pending"
          value={stats?.pending_tasks || 0}
          subtitle="Not started"
          icon={Clock}
          colorScheme="amber"
        />
        <StatCard
          title="Overdue"
          value={stats?.overdue_tasks || 0}
          subtitle="Passed deadlines"
          icon={AlertTriangle}
          colorScheme="rose"
        />
        <StatCard
          title="Total Subjects"
          value={stats?.total_subjects || 0}
          subtitle="Active modules"
          icon={FolderGit2}
          colorScheme="purple"
        />
      </div>

      {/* Charts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Pie / Donut Chart */}
        <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-4 border-b border-slate-100 mb-6">
              <div>
                <h2 className="font-bold text-slate-900 text-sm">Status Distribution (Donut Chart)</h2>
                <p className="text-xs text-slate-400">Proportional breakdown of all tasks</p>
              </div>
            </div>

            <DonutChart
              size={200}
              thickness={28}
              centerText={`${stats?.completion_percentage || 0}%`}
              centerSubtext="Completion Rate"
              data={[
                { label: 'Completed', value: stats?.completed_tasks || 0, color: '#10b981' },
                { label: 'In Progress', value: stats?.in_progress_tasks || 0, color: '#6366f1' },
                { label: 'Pending', value: stats?.pending_tasks || 0, color: '#f59e0b' },
                { label: 'Overdue', value: stats?.overdue_tasks || 0, color: '#ef4444' },
              ]}
            />
          </div>

          <div className="mt-8 pt-4 border-t border-slate-100 grid grid-cols-3 gap-2 text-center">
            <div className="p-2 rounded-xl bg-slate-50">
              <p className="text-[10px] text-slate-400 font-semibold uppercase">Total Hours</p>
              <p className="text-sm font-bold text-slate-800">{stats?.hours?.total || 0} hrs</p>
            </div>
            <div className="p-2 rounded-xl bg-emerald-50 text-emerald-800">
              <p className="text-[10px] font-semibold uppercase">Done Hours</p>
              <p className="text-sm font-bold">{stats?.hours?.completed || 0} hrs</p>
            </div>
            <div className="p-2 rounded-xl bg-amber-50 text-amber-800">
              <p className="text-[10px] font-semibold uppercase">Pending Hours</p>
              <p className="text-sm font-bold">{stats?.hours?.pending || 0} hrs</p>
            </div>
          </div>
        </div>

        {/* Subject-Wise Performance Bar Chart */}
        <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-4 border-b border-slate-100 mb-6">
              <div>
                <h2 className="font-bold text-slate-900 text-sm">Subject-Wise Completion (Bar Chart)</h2>
                <p className="text-xs text-slate-400">Progress percentage across each syllabus subject</p>
              </div>
            </div>

            {stats?.subjects && stats.subjects.length > 0 ? (
              <HorizontalBarChart
                items={stats.subjects.map((s) => ({
                  label: s.name,
                  sublabel: s.code || undefined,
                  completed: s.completed,
                  total: s.total,
                  color: s.color,
                }))}
              />
            ) : (
              <p className="text-xs text-slate-400 text-center py-10">No subjects to display.</p>
            )}
          </div>

          <div className="mt-6 pt-4 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
            <span>Priority Spread:</span>
            <span className="font-semibold text-slate-700">
              High: {stats?.priority_breakdown?.high || 0} • Medium: {stats?.priority_breakdown?.medium || 0} • Low: {stats?.priority_breakdown?.low || 0}
            </span>
          </div>
        </div>
      </div>

      {/* Subject Detailed Breakdown Table */}
      <div className="bg-white rounded-3xl border border-slate-200 shadow-xs overflow-hidden">
        <div className="p-5 border-b border-slate-100">
          <h2 className="text-sm font-bold text-slate-900">Subject Breakdown Table</h2>
          <p className="text-xs text-slate-400">Detailed metric summary per enrolled course</p>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-600">
            <thead className="bg-slate-50 text-[11px] font-bold text-slate-500 uppercase tracking-wider">
              <tr>
                <th className="px-5 py-3">Subject</th>
                <th className="px-4 py-3">Code</th>
                <th className="px-4 py-3 text-center">Total Tasks</th>
                <th className="px-4 py-3 text-center">Completed</th>
                <th className="px-4 py-3 text-center">In Progress</th>
                <th className="px-4 py-3 text-center">Pending</th>
                <th className="px-4 py-3 text-center">Overdue</th>
                <th className="px-4 py-3">Completion %</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {stats?.subjects?.map((sub) => (
                <tr key={sub.id} className="hover:bg-slate-50/70 transition-colors">
                  <td className="px-5 py-3 font-bold text-slate-900 flex items-center gap-2">
                    <span
                      className="h-2.5 w-2.5 rounded-full"
                      style={{ backgroundColor: sub.color || '#3b82f6' }}
                    />
                    <span>{sub.name}</span>
                  </td>
                  <td className="px-4 py-3 font-mono">{sub.code || '-'}</td>
                  <td className="px-4 py-3 text-center font-semibold text-slate-800">{sub.total}</td>
                  <td className="px-4 py-3 text-center font-bold text-emerald-600">{sub.completed}</td>
                  <td className="px-4 py-3 text-center text-indigo-600">{sub.inProgress}</td>
                  <td className="px-4 py-3 text-center text-amber-600">{sub.pending}</td>
                  <td className="px-4 py-3 text-center text-red-600 font-bold">{sub.overdue}</td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-2">
                      <div className="w-20">
                        <ProgressBar
                          value={sub.completed}
                          max={sub.total || 1}
                          color={sub.color || '#3b82f6'}
                        />
                      </div>
                      <span className="font-bold text-slate-900">{sub.completionPercentage}%</span>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
