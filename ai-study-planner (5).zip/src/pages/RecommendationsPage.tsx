import React, { useState, useEffect } from 'react';
import { api } from '../services/api.js';
import { RecommendationData, StudyRecommendation, DailyPlanItem } from '../types/index.js';
import {
  Sparkles,
  RefreshCw,
  AlertTriangle,
  BookOpen,
  Calendar,
  CheckCircle2,
  Clock,
  Zap,
  Info,
  Layers,
  ArrowRight,
} from 'lucide-react';

export const RecommendationsPage: React.FC = () => {
  const [data, setData] = useState<RecommendationData | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const fetchRecommendations = async () => {
    try {
      setIsLoading(true);
      setError(null);
      const res = await api.recommendations.get();
      if (res.success) {
        setData(res);
      }
    } catch (err: any) {
      setError(err.message || 'Failed to fetch AI study recommendations.');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchRecommendations();
  }, []);

  const getCategoryBadge = (category: string) => {
    switch (category) {
      case 'Urgent':
        return 'bg-red-50 text-red-700 border-red-200';
      case 'Subject Focus':
        return 'bg-indigo-50 text-indigo-700 border-indigo-200';
      case 'Schedule Optimization':
        return 'bg-purple-50 text-purple-700 border-purple-200';
      case 'Revision':
        return 'bg-emerald-50 text-emerald-700 border-emerald-200';
      default:
        return 'bg-slate-100 text-slate-700 border-slate-200';
    }
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="bg-gradient-to-r from-purple-900 via-indigo-900 to-blue-900 rounded-3xl p-6 sm:p-8 text-white shadow-md relative overflow-hidden">
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="max-w-2xl">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/10 backdrop-blur-md text-purple-200 text-xs font-semibold mb-3">
              <Sparkles className="h-3.5 w-3.5 text-amber-300 fill-amber-300" />
              <span>AI Study Recommendation Engine</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
              Personalized Academic Study Advice
            </h1>
            <p className="mt-2 text-purple-100/90 text-xs sm:text-sm leading-relaxed">
              Analyzes your actual pending coursework, priority weights, approaching deadlines, and subject
              distribution to formulate a high-yield study strategy.
            </p>
          </div>

          <div className="flex flex-col items-start md:items-end gap-2.5">
            <button
              onClick={fetchRecommendations}
              disabled={isLoading}
              className="px-4 py-2.5 rounded-xl font-bold text-xs bg-white text-indigo-900 hover:bg-indigo-50 shadow-xs transition-all flex items-center gap-2 self-start md:self-auto disabled:opacity-60"
            >
              <RefreshCw className={`h-4 w-4 ${isLoading ? 'animate-spin' : ''}`} />
              <span>{isLoading ? 'Analyzing Workload...' : 'Regenerate Recommendations'}</span>
            </button>

            {data?.source && (
              <span className="text-[11px] px-2.5 py-1 rounded-lg bg-white/15 text-white backdrop-blur-xs font-mono">
                Engine: {data.source}
              </span>
            )}
          </div>
        </div>
      </div>

      {error && (
        <div className="p-4 bg-red-50 border border-red-200 text-red-700 text-xs rounded-2xl">
          {error}
        </div>
      )}

      {/* Student Executive Summary */}
      {data?.studentSummary && (
        <div className="bg-white rounded-3xl border border-indigo-100 p-5 shadow-xs flex items-start gap-3.5">
          <div className="p-2.5 rounded-xl bg-indigo-50 text-indigo-600 shrink-0">
            <Zap className="h-5 w-5 fill-indigo-600" />
          </div>
          <div>
            <h2 className="text-xs font-bold text-indigo-950 uppercase tracking-wider">
              Diagnostic Assessment
            </h2>
            <p className="mt-1 text-sm text-slate-700 leading-relaxed font-medium">
              {data.studentSummary}
            </p>
          </div>
        </div>
      )}

      {/* Actionable Recommendations List */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
            <Sparkles className="h-4 w-4 text-indigo-600" />
            Strategic Study Recommendations ({data?.recommendations?.length || 0})
          </h2>
          <span className="text-xs text-slate-400">Personalized to your enrolled subjects</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {data?.recommendations?.map((rec: StudyRecommendation) => (
            <div
              key={rec.id}
              className="bg-white rounded-3xl border border-slate-200 p-6 shadow-xs hover:border-indigo-300 transition-all flex flex-col justify-between"
            >
              <div>
                <div className="flex items-start justify-between gap-2">
                  <span
                    className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${getCategoryBadge(
                      rec.category
                    )}`}
                  >
                    {rec.category}
                  </span>

                  <span
                    className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                      rec.priorityLevel === 'High'
                        ? 'bg-red-50 text-red-700 border border-red-200'
                        : rec.priorityLevel === 'Medium'
                        ? 'bg-amber-50 text-amber-700 border border-amber-200'
                        : 'bg-blue-50 text-blue-700 border border-blue-200'
                    }`}
                  >
                    {rec.priorityLevel} Priority
                  </span>
                </div>

                <h3 className="mt-3 text-sm font-bold text-slate-900">{rec.title}</h3>
                <p className="mt-2 text-xs text-slate-600 leading-relaxed">{rec.recommendation}</p>

                {/* Actionable Next Step Callout */}
                <div className="mt-4 p-3 rounded-2xl bg-slate-50 border border-slate-100 flex items-start gap-2 text-xs text-slate-700">
                  <ArrowRight className="h-4 w-4 text-indigo-600 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-bold text-slate-900">Action Step: </span>
                    <span>{rec.actionableStep}</span>
                  </div>
                </div>
              </div>

              <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
                <span>{rec.targetSubject ? `Focus: ${rec.targetSubject}` : 'General Strategy'}</span>
                {rec.suggestedHours && (
                  <span className="font-mono text-indigo-600 font-bold">
                    ~{rec.suggestedHours} hrs recommended
                  </span>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Suggested 5-Day Study Timetable */}
      {data?.dailyStudyPlan && data.dailyStudyPlan.length > 0 && (
        <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div>
              <h2 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                <Calendar className="h-4 w-4 text-indigo-600" />
                Suggested 5-Day Revision Timetable
              </h2>
              <p className="text-xs text-slate-400">
                Optimized allocation to balance pending course topics across upcoming weekdays
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
            {data.dailyStudyPlan.map((plan: DailyPlanItem, idx: number) => (
              <div
                key={idx}
                className="p-4 rounded-2xl border border-slate-200/90 bg-slate-50/50 hover:bg-indigo-50/30 hover:border-indigo-200 transition-all flex flex-col justify-between"
              >
                <div>
                  <span className="text-xs font-bold text-indigo-900 block">{plan.day}</span>
                  <span className="mt-1 text-[11px] font-semibold px-2 py-0.5 rounded-full bg-white border border-slate-200 text-slate-700 inline-block">
                    {plan.focusSubject}
                  </span>

                  <ul className="mt-2.5 space-y-1">
                    {plan.targetTasks.map((t: string, i: number) => (
                      <li key={i} className="text-[11px] text-slate-600 line-clamp-2">
                        • {t}
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="mt-4 pt-2 border-t border-slate-200/60 flex items-center justify-between text-[11px] text-slate-500 font-mono">
                  <span>Target Time:</span>
                  <span className="font-bold text-slate-900">{plan.allocatedHours} hrs</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Academic Viva Context Box */}
      <div className="bg-slate-50 rounded-3xl border border-slate-200 p-5 text-xs text-slate-600 flex items-start gap-3">
        <Info className="h-5 w-5 text-indigo-600 shrink-0 mt-0.5" />
        <div>
          <h4 className="font-bold text-slate-900 mb-0.5">
            BCA Viva Demonstration Notes on Recommendation Engine:
          </h4>
          <p className="leading-relaxed">
            This module implements a dual-engine architecture. When connected with Google Gemini API
            (model <code className="font-mono bg-white px-1.5 py-0.5 rounded border border-slate-200">gemini-3.8-flash</code>),
            the backend sends structured JSON prompts containing the student's actual database records.
            If the API key is not supplied or offline, the system seamlessly uses an intelligent
            rule-based algorithm calculating deadline proximity (<code className="font-mono">deadline &lt;= CURDATE() + 1</code>),
            high-priority status, and subject imbalance to ensure 100% reliability during viva examinations.
          </p>
        </div>
      </div>
    </div>
  );
};
