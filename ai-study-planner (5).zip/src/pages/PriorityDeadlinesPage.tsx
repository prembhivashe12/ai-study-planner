import React, { useState, useEffect } from 'react';
import { api } from '../services/api.js';
import { Task, Priority, TaskStatus } from '../types/index.js';
import { AlertTriangle, Clock, Calendar, CheckCircle2, ArrowUpDown } from 'lucide-react';

interface PriorityDeadlinesPageProps {
  onEditTask: (task: Task) => void;
}

export const PriorityDeadlinesPage: React.FC<PriorityDeadlinesPageProps> = ({
  onEditTask,
}) => {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [activeTab, setActiveTab] = useState<'priority' | 'deadline'>('priority');
  const [sortBy, setSortBy] = useState<string>('deadline');
  const [isLoading, setIsLoading] = useState(true);

  const loadTasks = async () => {
    try {
      setIsLoading(true);
      const res = await api.tasks.getAll();
      if (res.success) setTasks(res.tasks);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadTasks();
  }, []);

  const handleStatusChange = async (taskId: number, newStatus: TaskStatus) => {
    try {
      await api.tasks.updateStatus(taskId, newStatus);
      setTasks((prev) =>
        prev.map((t) => (t.id === taskId ? { ...t, status: newStatus } : t))
      );
    } catch (err: any) {
      alert('Failed to update status: ' + err.message);
    }
  };

  const todayStr = new Date().toISOString().split('T')[0];
  const tomorrow = new Date();
  tomorrow.setDate(tomorrow.getDate() + 1);
  const tomorrowStr = tomorrow.toISOString().split('T')[0];

  // Group by priority
  const highPriorityTasks = tasks.filter((t) => t.priority === 'High');
  const mediumPriorityTasks = tasks.filter((t) => t.priority === 'Medium');
  const lowPriorityTasks = tasks.filter((t) => t.priority === 'Low');

  // Group by deadline
  const overdueTasks = tasks.filter((t) => t.deadline < todayStr && t.status !== 'Completed');
  const dueTodayTasks = tasks.filter((t) => t.deadline === todayStr && t.status !== 'Completed');
  const dueTomorrowTasks = tasks.filter((t) => t.deadline === tomorrowStr && t.status !== 'Completed');
  const upcomingTasks = tasks.filter((t) => t.deadline > tomorrowStr && t.status !== 'Completed');
  const completedTasks = tasks.filter((t) => t.status === 'Completed');

  const renderTaskCard = (task: Task) => {
    const isOverdue = task.deadline < todayStr && task.status !== 'Completed';
    const isDueToday = task.deadline === todayStr;

    return (
      <div
        key={task.id}
        className="p-4 rounded-2xl border border-slate-200/90 bg-white hover:border-slate-300 transition-all shadow-xs flex flex-col justify-between gap-3"
      >
        <div>
          <div className="flex items-start justify-between gap-2">
            <span
              className="text-[10px] font-semibold px-2 py-0.5 rounded-full"
              style={{
                backgroundColor: (task.subject_color || '#3b82f6') + '20',
                color: task.subject_color || '#3b82f6',
              }}
            >
              {task.subject_name}
            </span>

            <span
              className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                task.priority === 'High'
                  ? 'bg-red-50 text-red-700 border border-red-200'
                  : task.priority === 'Medium'
                  ? 'bg-amber-50 text-amber-700 border border-amber-200'
                  : 'bg-blue-50 text-blue-700 border border-blue-200'
              }`}
            >
              {task.priority} Priority
            </span>
          </div>

          <h3
            onClick={() => onEditTask(task)}
            className={`mt-2 text-xs font-bold cursor-pointer hover:text-indigo-600 transition-colors ${
              task.status === 'Completed' ? 'line-through text-slate-400' : 'text-slate-900'
            }`}
          >
            {task.title}
          </h3>

          {task.description && (
            <p className="mt-1 text-[11px] text-slate-500 line-clamp-2">
              {task.description}
            </p>
          )}
        </div>

        <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-xs">
          <div className="flex items-center gap-1.5 font-mono text-[11px] text-slate-500">
            <Calendar className="h-3 w-3 text-slate-400" />
            <span className={isOverdue ? 'text-red-600 font-bold' : isDueToday ? 'text-amber-600 font-bold' : ''}>
              {task.deadline}
            </span>
          </div>

          <button
            onClick={() =>
              handleStatusChange(
                task.id,
                task.status === 'Completed' ? 'Pending' : 'Completed'
              )
            }
            className={`px-2 py-0.5 rounded-lg text-[10px] font-bold transition-colors ${
              task.status === 'Completed'
                ? 'bg-emerald-100 text-emerald-800'
                : 'bg-slate-100 text-slate-600 hover:bg-emerald-50 hover:text-emerald-700'
            }`}
          >
            {task.status === 'Completed' ? 'Completed ✓' : 'Mark Done'}
          </button>
        </div>
      </div>
    );
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900 flex items-center gap-2">
            <AlertTriangle className="h-5 w-5 text-indigo-600" />
            Priority Matrix & Deadline Radar
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Identify what needs urgent preparation and sort tasks to avoid missed deadlines
          </p>
        </div>

        {/* View Toggle */}
        <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-2xl self-start sm:self-auto">
          <button
            onClick={() => setActiveTab('priority')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
              activeTab === 'priority'
                ? 'bg-white text-indigo-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Group by Priority
          </button>
          <button
            onClick={() => setActiveTab('deadline')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
              activeTab === 'deadline'
                ? 'bg-white text-indigo-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Group by Deadline
          </button>
        </div>
      </div>

      {/* Mode 1: Priority Columns */}
      {activeTab === 'priority' && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          {/* High Priority */}
          <div className="bg-red-50/40 rounded-3xl border border-red-200/80 p-5 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-red-200">
              <div className="flex items-center gap-2">
                <span className="h-3 w-3 rounded-full bg-red-600 animate-pulse" />
                <h2 className="font-bold text-red-950 text-sm">High Priority</h2>
              </div>
              <span className="px-2 py-0.5 bg-red-100 text-red-700 text-xs font-bold rounded-full">
                {highPriorityTasks.length} Tasks
              </span>
            </div>
            <div className="space-y-3">
              {highPriorityTasks.length === 0 ? (
                <p className="text-xs text-slate-400 py-6 text-center">No high priority tasks.</p>
              ) : (
                highPriorityTasks.map(renderTaskCard)
              )}
            </div>
          </div>

          {/* Medium Priority */}
          <div className="bg-amber-50/40 rounded-3xl border border-amber-200/80 p-5 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-amber-200">
              <div className="flex items-center gap-2">
                <span className="h-3 w-3 rounded-full bg-amber-500" />
                <h2 className="font-bold text-amber-950 text-sm">Medium Priority</h2>
              </div>
              <span className="px-2 py-0.5 bg-amber-100 text-amber-800 text-xs font-bold rounded-full">
                {mediumPriorityTasks.length} Tasks
              </span>
            </div>
            <div className="space-y-3">
              {mediumPriorityTasks.length === 0 ? (
                <p className="text-xs text-slate-400 py-6 text-center">No medium priority tasks.</p>
              ) : (
                mediumPriorityTasks.map(renderTaskCard)
              )}
            </div>
          </div>

          {/* Low Priority */}
          <div className="bg-blue-50/40 rounded-3xl border border-blue-200/80 p-5 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-blue-200">
              <div className="flex items-center gap-2">
                <span className="h-3 w-3 rounded-full bg-blue-500" />
                <h2 className="font-bold text-blue-950 text-sm">Low Priority</h2>
              </div>
              <span className="px-2 py-0.5 bg-blue-100 text-blue-800 text-xs font-bold rounded-full">
                {lowPriorityTasks.length} Tasks
              </span>
            </div>
            <div className="space-y-3">
              {lowPriorityTasks.length === 0 ? (
                <p className="text-xs text-slate-400 py-6 text-center">No low priority tasks.</p>
              ) : (
                lowPriorityTasks.map(renderTaskCard)
              )}
            </div>
          </div>
        </div>
      )}

      {/* Mode 2: Deadline Radar */}
      {activeTab === 'deadline' && (
        <div className="space-y-6">
          {/* Overdue Section */}
          {overdueTasks.length > 0 && (
            <div className="bg-red-50/50 rounded-3xl border border-red-200 p-6 space-y-4">
              <div className="flex items-center gap-2">
                <AlertTriangle className="h-5 w-5 text-red-600" />
                <h2 className="text-sm font-bold text-red-900">
                  Overdue Tasks ({overdueTasks.length}) — Attention Required!
                </h2>
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                {overdueTasks.map(renderTaskCard)}
              </div>
            </div>
          )}

          {/* Due Today Section */}
          <div className="bg-amber-50/40 rounded-3xl border border-amber-200 p-6 space-y-4">
            <div className="flex items-center gap-2">
              <Clock className="h-5 w-5 text-amber-600" />
              <h2 className="text-sm font-bold text-amber-900">
                Due Today ({dueTodayTasks.length})
              </h2>
            </div>
            {dueTodayTasks.length === 0 ? (
              <p className="text-xs text-slate-400">No pending tasks due today. Great job!</p>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                {dueTodayTasks.map(renderTaskCard)}
              </div>
            )}
          </div>

          {/* Due Tomorrow */}
          <div className="bg-blue-50/40 rounded-3xl border border-blue-200 p-6 space-y-4">
            <div className="flex items-center gap-2">
              <Calendar className="h-5 w-5 text-blue-600" />
              <h2 className="text-sm font-bold text-blue-900">
                Due Tomorrow ({dueTomorrowTasks.length})
              </h2>
            </div>
            {dueTomorrowTasks.length === 0 ? (
              <p className="text-xs text-slate-400">No pending tasks due tomorrow.</p>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                {dueTomorrowTasks.map(renderTaskCard)}
              </div>
            )}
          </div>

          {/* Upcoming */}
          <div className="bg-white rounded-3xl border border-slate-200 p-6 space-y-4 shadow-xs">
            <h2 className="text-sm font-bold text-slate-900">
              Upcoming Deadlines ({upcomingTasks.length})
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              {upcomingTasks.map(renderTaskCard)}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
