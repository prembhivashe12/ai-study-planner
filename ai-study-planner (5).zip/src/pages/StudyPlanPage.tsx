import React, { useState, useEffect } from 'react';
import { api } from '../services/api.js';
import { Task, TaskStatus } from '../types/index.js';
import { Calendar, Clock, CheckCircle2, AlertTriangle, ArrowLeft, ArrowRight } from 'lucide-react';

interface StudyPlanPageProps {
  onEditTask: (task: Task) => void;
  onOpenAddTask: () => void;
}

export const StudyPlanPage: React.FC<StudyPlanPageProps> = ({ onEditTask, onOpenAddTask }) => {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [selectedDate, setSelectedDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [isLoading, setIsLoading] = useState(true);

  const loadTasks = async () => {
    try {
      setIsLoading(true);
      const res = await api.tasks.getAll();
      if (res.success) setTasks(res.tasks);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadTasks();
  }, []);

  const handleStatusChange = async (taskId: number, newStatus: TaskStatus) => {
    try {
      await api.tasks.updateStatus(taskId, newStatus);
      setTasks((prev) =>
        prev.map((t) => (t.id === taskId ? { ...t, status: newStatus } : t))
      );
    } catch (err: any) {
      alert('Failed to update task status: ' + err.message);
    }
  };

  const todayStr = new Date().toISOString().split('T')[0];

  // Helper to generate next 7 days for the date selector strip
  const dateStrip = Array.from({ length: 7 }, (_, i) => {
    const d = new Date();
    d.setDate(d.getDate() + i - 1); // Yesterday to 5 days ahead
    const dateKey = d.toISOString().split('T')[0];
    const dayName = d.toLocaleDateString('en-US', { weekday: 'short' });
    const dayNum = d.getDate();
    const isToday = dateKey === todayStr;
    const taskCount = tasks.filter((t) => t.deadline === dateKey).length;
    return { dateKey, dayName, dayNum, isToday, taskCount };
  });

  const selectedTasks = tasks.filter((t) => t.deadline === selectedDate);
  const tasksDueToday = tasks.filter((t) => t.deadline === todayStr);

  const tomorrow = new Date();
  tomorrow.setDate(tomorrow.getDate() + 1);
  const tomorrowStr = tomorrow.toISOString().split('T')[0];
  const tasksDueTomorrow = tasks.filter((t) => t.deadline === tomorrowStr);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900 flex items-center gap-2">
            <Calendar className="h-5 w-5 text-indigo-600" />
            Study Plan & Daily Agenda
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Organize study blocks by date, track what to study today, and plan for upcoming exam deadlines
          </p>
        </div>

        <button
          onClick={onOpenAddTask}
          className="px-4 py-2.5 rounded-xl font-bold text-xs text-white bg-indigo-600 hover:bg-indigo-700 shadow-xs transition-colors self-start sm:self-auto"
        >
          + Add Scheduled Task
        </button>
      </div>

      {/* Date Navigator Strip */}
      <div className="bg-white p-4 rounded-3xl border border-slate-200 shadow-xs">
        <div className="flex items-center justify-between mb-3 px-2">
          <span className="text-xs font-bold text-slate-700">Quick Date Selector:</span>
          <span className="text-xs font-mono text-indigo-600 font-bold">Selected: {selectedDate}</span>
        </div>

        <div className="grid grid-cols-7 gap-2">
          {dateStrip.map((item) => {
            const isSelected = selectedDate === item.dateKey;
            return (
              <button
                key={item.dateKey}
                onClick={() => setSelectedDate(item.dateKey)}
                className={`py-3 px-2 rounded-2xl border text-center transition-all flex flex-col items-center justify-center relative ${
                  isSelected
                    ? 'bg-indigo-600 border-indigo-600 text-white shadow-md shadow-indigo-100'
                    : item.isToday
                    ? 'bg-indigo-50/70 border-indigo-200 text-indigo-950'
                    : 'bg-slate-50 border-slate-200/80 text-slate-700 hover:bg-slate-100'
                }`}
              >
                <span className={`text-[10px] uppercase font-bold ${isSelected ? 'text-indigo-200' : 'text-slate-400'}`}>
                  {item.dayName}
                </span>
                <span className="text-lg font-black tracking-tight my-0.5">{item.dayNum}</span>
                {item.taskCount > 0 && (
                  <span
                    className={`text-[9px] px-1.5 py-0.2 rounded-full font-bold mt-1 ${
                      isSelected ? 'bg-white text-indigo-900' : 'bg-indigo-600 text-white'
                    }`}
                  >
                    {item.taskCount} {item.taskCount === 1 ? 'task' : 'tasks'}
                  </span>
                )}
                {item.isToday && !isSelected && (
                  <span className="absolute -top-1.5 px-1.5 py-0.2 rounded text-[8px] bg-indigo-600 text-white font-bold">
                    TODAY
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* 2-Column: Agenda for Selected Date & Quick Tomorrow/Upcoming Radar */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left: Selected Date Tasks */}
        <div className="lg:col-span-2 bg-white rounded-3xl border border-slate-200 p-6 shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div>
              <h2 className="text-sm font-bold text-slate-900">
                Tasks Scheduled for {selectedDate} {selectedDate === todayStr ? '(Today)' : ''}
              </h2>
              <p className="text-xs text-slate-400">{selectedTasks.length} study tasks due on this date</p>
            </div>
          </div>

          <div className="space-y-3">
            {selectedTasks.length === 0 ? (
              <div className="text-center py-12 text-slate-400">
                <Calendar className="h-10 w-10 mx-auto text-slate-300 mb-2" />
                <p className="text-xs font-semibold text-slate-600">No deadlines scheduled for {selectedDate}</p>
                <p className="text-xs text-slate-400 mt-1">Use this date for free revision or choose another date.</p>
              </div>
            ) : (
              selectedTasks.map((task) => (
                <div
                  key={task.id}
                  className="p-4 rounded-2xl border border-slate-200/80 bg-slate-50/50 hover:bg-white hover:shadow-xs transition-all flex items-center justify-between gap-3"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <button
                      onClick={() =>
                        handleStatusChange(
                          task.id,
                          task.status === 'Completed' ? 'Pending' : 'Completed'
                        )
                      }
                      className={`h-5 w-5 rounded-md border flex items-center justify-center transition-colors shrink-0 ${
                        task.status === 'Completed'
                          ? 'bg-emerald-600 border-emerald-600 text-white'
                          : 'border-slate-300 bg-white'
                      }`}
                    >
                      {task.status === 'Completed' && <CheckCircle2 className="h-4 w-4" />}
                    </button>

                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <span
                          onClick={() => onEditTask(task)}
                          className={`text-xs font-bold cursor-pointer hover:text-indigo-600 truncate ${
                            task.status === 'Completed' ? 'line-through text-slate-400' : 'text-slate-900'
                          }`}
                        >
                          {task.title}
                        </span>
                        <span
                          className="text-[10px] font-semibold px-2 py-0.5 rounded-full"
                          style={{
                            backgroundColor: (task.subject_color || '#3b82f6') + '20',
                            color: task.subject_color || '#3b82f6',
                          }}
                        >
                          {task.subject_name}
                        </span>
                      </div>
                      {task.description && (
                        <p className="text-[11px] text-slate-500 mt-1 truncate max-w-md">
                          {task.description}
                        </p>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center gap-3 shrink-0">
                    <span className="text-xs font-mono text-slate-400 flex items-center gap-1">
                      <Clock className="h-3.5 w-3.5" />
                      {task.estimated_hours} hrs
                    </span>

                    <span
                      className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                        task.priority === 'High'
                          ? 'bg-red-50 text-red-700 border border-red-200'
                          : task.priority === 'Medium'
                          ? 'bg-amber-50 text-amber-700 border border-amber-200'
                          : 'bg-blue-50 text-blue-700 border border-blue-200'
                      }`}
                    >
                      {task.priority}
                    </span>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        {/* Right: What is due tomorrow & Upcoming deadlines summary */}
        <div className="space-y-6">
          {/* Due Tomorrow Card */}
          <div className="bg-white rounded-3xl border border-slate-200 p-5 shadow-xs space-y-3">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <h3 className="text-xs font-bold text-slate-900 flex items-center gap-1.5">
                <Clock className="h-4 w-4 text-blue-600" />
                Due Tomorrow ({tasksDueTomorrow.length})
              </h3>
              <span className="text-[11px] font-mono text-slate-400">{tomorrowStr}</span>
            </div>

            {tasksDueTomorrow.length === 0 ? (
              <p className="text-xs text-slate-400 py-3 text-center">Nothing due tomorrow. Clear runway!</p>
            ) : (
              <div className="space-y-2">
                {tasksDueTomorrow.map((t) => (
                  <div key={t.id} className="p-2.5 rounded-xl bg-blue-50/50 border border-blue-100 text-xs">
                    <p className="font-bold text-blue-950 truncate">{t.title}</p>
                    <div className="flex items-center justify-between text-[11px] text-blue-700 mt-1">
                      <span>{t.subject_name}</span>
                      <span className="font-mono">{t.estimated_hours} hrs</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Today's Priority Work */}
          <div className="bg-white rounded-3xl border border-slate-200 p-5 shadow-xs space-y-3">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <h3 className="text-xs font-bold text-slate-900 flex items-center gap-1.5">
                <AlertTriangle className="h-4 w-4 text-amber-500" />
                Today's Core Targets ({tasksDueToday.length})
              </h3>
              <span className="text-[11px] font-mono text-slate-400">{todayStr}</span>
            </div>

            {tasksDueToday.length === 0 ? (
              <p className="text-xs text-slate-400 py-3 text-center">No tasks designated specifically for today.</p>
            ) : (
              <div className="space-y-2">
                {tasksDueToday.map((t) => (
                  <div key={t.id} className="p-2.5 rounded-xl bg-amber-50/50 border border-amber-100 text-xs">
                    <p className="font-bold text-amber-950 truncate">{t.title}</p>
                    <div className="flex items-center justify-between text-[11px] text-amber-800 mt-1">
                      <span>{t.subject_name}</span>
                      <span className="font-mono">{t.status}</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
