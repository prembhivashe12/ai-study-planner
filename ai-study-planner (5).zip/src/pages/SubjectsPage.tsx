import React, { useState, useEffect } from 'react';
import { api } from '../services/api.js';
import { Subject, Task } from '../types/index.js';
import { Plus, Edit2, Trash2, FolderGit2, BookOpen, Layers } from 'lucide-react';
import { ProgressBar } from '../components/Charts.js';

interface SubjectsPageProps {
  onOpenAddSubject: () => void;
  onEditSubject: (subject: Subject) => void;
  onDeleteSubject: (subject: Subject) => void;
  onSelectSubjectPlan: (subjectId: number) => void;
}

export const SubjectsPage: React.FC<SubjectsPageProps> = ({
  onOpenAddSubject,
  onEditSubject,
  onDeleteSubject,
  onSelectSubjectPlan,
}) => {
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [tasks, setTasks] = useState<Task[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const loadData = async () => {
    try {
      setIsLoading(true);
      setError(null);
      const [subRes, taskRes] = await Promise.all([
        api.subjects.getAll(),
        api.tasks.getAll(),
      ]);

      if (subRes.success) setSubjects(subRes.subjects);
      if (taskRes.success) setTasks(taskRes.tasks);
    } catch (err: any) {
      setError(err.message || 'Failed to load subjects.');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-6 rounded-3xl border border-slate-200 shadow-xs">
        <div>
          <h1 className="text-xl font-bold text-slate-900 flex items-center gap-2">
            <FolderGit2 className="h-5 w-5 text-indigo-600" />
            Subject Management
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Add and manage your academic subjects (e.g. Java, DBMS, Web Development, Networks)
          </p>
        </div>
        <button
          onClick={onOpenAddSubject}
          className="px-4 py-2.5 rounded-xl font-bold text-xs text-white bg-indigo-600 hover:bg-indigo-700 shadow-xs transition-all flex items-center gap-2 self-start sm:self-auto"
        >
          <Plus className="h-4 w-4" />
          <span>Add Academic Subject</span>
        </button>
      </div>

      {error && (
        <div className="p-4 bg-red-50 border border-red-200 text-red-700 text-xs rounded-2xl">
          {error}
        </div>
      )}

      {/* Subject Cards Grid */}
      {subjects.length === 0 ? (
        <div className="bg-white rounded-3xl border border-slate-200 p-12 text-center shadow-xs">
          <FolderGit2 className="h-12 w-12 text-slate-300 mx-auto mb-3" />
          <h3 className="font-bold text-slate-800 text-sm">No Subjects Added Yet</h3>
          <p className="text-xs text-slate-400 mt-1 max-w-sm mx-auto">
            Create your core academic subjects to start organizing coursework and syllabus tasks.
          </p>
          <button
            onClick={onOpenAddSubject}
            className="mt-4 px-4 py-2 rounded-xl bg-indigo-600 text-white font-bold text-xs shadow-xs hover:bg-indigo-700 transition-colors"
          >
            Add First Subject
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {subjects.map((sub) => {
            const subjectTasks = tasks.filter((t) => t.subject_id === sub.id);
            const completedCount = subjectTasks.filter((t) => t.status === 'Completed').length;
            const totalCount = subjectTasks.length;
            const completionPct = totalCount > 0 ? Math.round((completedCount / totalCount) * 100) : 0;
            const totalHours = subjectTasks.reduce((acc, t) => acc + Number(t.estimated_hours || 0), 0);

            return (
              <div
                key={sub.id}
                className="bg-white rounded-3xl border border-slate-200 p-6 shadow-xs hover:shadow-md transition-all flex flex-col justify-between"
              >
                <div>
                  {/* Card top */}
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-center gap-3">
                      <div
                        className="h-10 w-10 rounded-2xl flex items-center justify-center font-bold text-white shadow-xs"
                        style={{ backgroundColor: sub.color || '#3b82f6' }}
                      >
                        {sub.name.charAt(0).toUpperCase()}
                      </div>
                      <div>
                        <h2 className="font-bold text-slate-900 text-sm leading-snug">{sub.name}</h2>
                        {sub.code && (
                          <span className="text-[11px] font-mono font-semibold px-1.5 py-0.5 rounded bg-slate-100 text-slate-600">
                            {sub.code}
                          </span>
                        )}
                      </div>
                    </div>

                    <div className="flex items-center gap-1">
                      <button
                        onClick={() => onEditSubject(sub)}
                        className="p-1.5 text-slate-400 hover:text-indigo-600 rounded-lg hover:bg-slate-100 transition-colors"
                        title="Edit Subject"
                      >
                        <Edit2 className="h-3.5 w-3.5" />
                      </button>
                      <button
                        onClick={() => onDeleteSubject(sub)}
                        className="p-1.5 text-slate-400 hover:text-red-600 rounded-lg hover:bg-red-50 transition-colors"
                        title="Delete Subject"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  </div>

                  {/* Description */}
                  <p className="mt-3 text-xs text-slate-500 line-clamp-2">
                    {sub.description || 'No description provided for this syllabus subject.'}
                  </p>

                  {/* Progress details */}
                  <div className="mt-5 space-y-1.5">
                    <div className="flex items-center justify-between text-xs">
                      <span className="text-slate-500 font-medium">Task Completion:</span>
                      <span className="font-bold text-slate-900">
                        {completedCount} / {totalCount} ({completionPct}%)
                      </span>
                    </div>
                    <ProgressBar value={completedCount} max={totalCount || 1} color={sub.color || '#3b82f6'} />
                  </div>
                </div>

                {/* Footer action */}
                <div className="mt-5 pt-4 border-t border-slate-100 flex items-center justify-between text-xs">
                  <span className="text-slate-400 font-mono">
                    {totalHours.toFixed(1)} hrs total
                  </span>
                  <button
                    onClick={() => onSelectSubjectPlan(sub.id)}
                    className="font-bold text-indigo-600 hover:text-indigo-800 flex items-center gap-1"
                  >
                    <Layers className="h-3.5 w-3.5" />
                    <span>View Plan</span>
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
