import React from 'react';
import { useAuth } from '../context/AuthContext.js';
import {
  GraduationCap,
  Sparkles,
  Layers,
  BarChart3,
  Calendar,
  CheckCircle2,
  ArrowRight,
  ShieldCheck,
  Server,
  Zap,
  Download,
} from 'lucide-react';

interface LandingPageProps {
  onNavigateLogin: () => void;
  onNavigateRegister: () => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({
  onNavigateLogin,
  onNavigateRegister,
}) => {
  const { quickDemoLogin, isLoading } = useAuth();

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 flex flex-col justify-between">
      {/* Top Header */}
      <header className="border-b border-slate-200 bg-white/80 backdrop-blur-md sticky top-0 z-30">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-xl bg-gradient-to-tr from-indigo-600 to-blue-500 flex items-center justify-center text-white shadow-md shadow-indigo-100">
              <GraduationCap className="h-6 w-6" />
            </div>
            <div>
              <span className="font-extrabold text-slate-900 tracking-tight text-lg">AI Study Planner</span>
              <span className="ml-2 text-xs font-semibold px-2 py-0.5 rounded bg-indigo-50 text-indigo-700 border border-indigo-100">
                Problem Statement 16
              </span>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <a
              href="/ai-study-planner.zip"
              download="ai-study-planner.zip"
              className="text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 px-3.5 py-2 rounded-xl shadow-xs transition-all flex items-center gap-1.5"
            >
              <Download className="h-3.5 w-3.5" />
              <span>Download ZIP</span>
            </a>
            <button
              onClick={onNavigateLogin}
              className="text-xs font-semibold text-slate-700 hover:text-indigo-600 px-3 py-2 rounded-lg transition-colors"
            >
              Sign In
            </button>
            <button
              onClick={onNavigateRegister}
              className="text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 px-4 py-2 rounded-xl shadow-xs transition-all"
            >
              Create Account
            </button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <main className="flex-1">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 md:py-20">
          <div className="text-center max-w-3xl mx-auto">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-50 border border-indigo-200/60 text-indigo-700 text-xs font-semibold mb-6">
              <Sparkles className="h-3.5 w-3.5 text-indigo-600" />
              <span>BCA 3rd Year Academic Project • Feature Set C Complete</span>
            </div>

            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-black text-slate-950 tracking-tight leading-tight sm:leading-none">
              Organize, Prioritize & Excel in Your{' '}
              <span className="bg-gradient-to-r from-indigo-600 to-blue-600 bg-clip-text text-transparent">
                Semester Exams
              </span>
            </h1>

            <p className="mt-6 text-base sm:text-lg text-slate-600 leading-relaxed">
              A full-stack academic study organizer built with React, Node.js, Express, and MySQL.
              Manage your subjects, track priority deadlines, visualize progress with interactive charts,
              and receive personalized AI study recommendations.
            </p>

            {/* Quick Demo CTA */}
            <div className="mt-8 flex flex-col sm:flex-row items-center justify-center gap-3">
              <button
                onClick={quickDemoLogin}
                disabled={isLoading}
                className="w-full sm:w-auto px-6 py-3.5 rounded-xl font-bold text-sm text-white bg-gradient-to-r from-indigo-600 to-blue-600 hover:from-indigo-700 hover:to-blue-700 shadow-md shadow-indigo-200 transition-all flex items-center justify-center gap-2 group"
              >
                <Zap className="h-4 w-4 text-amber-300 fill-amber-300" />
                <span>One-Click Examiner Demo Login</span>
                <ArrowRight className="h-4 w-4 group-hover:translate-x-1 transition-transform" />
              </button>

              <a
                href="/ai-study-planner.zip"
                download="ai-study-planner.zip"
                className="w-full sm:w-auto px-6 py-3.5 rounded-xl font-bold text-sm text-white bg-emerald-600 hover:bg-emerald-700 shadow-md shadow-emerald-100 transition-colors flex items-center justify-center gap-2"
              >
                <Download className="h-4 w-4" />
                <span>Download Full Project ZIP</span>
              </a>

              <button
                onClick={onNavigateLogin}
                className="w-full sm:w-auto px-6 py-3.5 rounded-xl font-bold text-sm text-slate-700 bg-white hover:bg-slate-50 border border-slate-300 transition-colors shadow-xs"
              >
                Sign In
              </button>
            </div>

            <p className="mt-3 text-xs text-slate-400">
              Demo account pre-loaded with Java, DBMS, Web Development, Networks & Python syllabus tasks.
            </p>
          </div>

          {/* Mandatory Feature Set C Showcase */}
          <div className="mt-16 md:mt-24">
            <div className="text-center mb-10">
              <h2 className="text-2xl font-black text-slate-900">Feature Set C Requirements Met</h2>
              <p className="text-xs text-slate-500 mt-1">All 7 mandatory features fully implemented with real database persistence</p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
              <div className="bg-white rounded-2xl border border-slate-200/80 p-5 shadow-xs hover:border-indigo-300 transition-all">
                <div className="h-10 w-10 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center mb-3">
                  <CheckCircle2 className="h-5 w-5" />
                </div>
                <h3 className="font-bold text-slate-900 text-sm">1-3. Task CRUD Management</h3>
                <p className="text-xs text-slate-500 mt-1.5 leading-relaxed">
                  Add, edit, delete, and mark study tasks as Pending, In Progress, or Completed with custom hours.
                </p>
              </div>

              <div className="bg-white rounded-2xl border border-slate-200/80 p-5 shadow-xs hover:border-indigo-300 transition-all">
                <div className="h-10 w-10 rounded-xl bg-purple-50 text-purple-600 flex items-center justify-center mb-3">
                  <Layers className="h-5 w-5" />
                </div>
                <h3 className="font-bold text-slate-900 text-sm">4. Subject-Wise Planning</h3>
                <p className="text-xs text-slate-500 mt-1.5 leading-relaxed">
                  Group tasks by BCA subjects (Java, DBMS, Web Tech) with dedicated completion progress bars.
                </p>
              </div>

              <div className="bg-white rounded-2xl border border-slate-200/80 p-5 shadow-xs hover:border-indigo-300 transition-all">
                <div className="h-10 w-10 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center mb-3">
                  <Calendar className="h-5 w-5" />
                </div>
                <h3 className="font-bold text-slate-900 text-sm">5. Priority & Deadlines</h3>
                <p className="text-xs text-slate-500 mt-1.5 leading-relaxed">
                  High, Medium, and Low matrix with real-time deadline categorization (Overdue, Due Today, Due Tomorrow).
                </p>
              </div>

              <div className="bg-white rounded-2xl border border-slate-200/80 p-5 shadow-xs hover:border-indigo-300 transition-all">
                <div className="h-10 w-10 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center mb-3">
                  <Sparkles className="h-5 w-5" />
                </div>
                <h3 className="font-bold text-slate-900 text-sm">6-7. Stats & AI Advice</h3>
                <p className="text-xs text-slate-500 mt-1.5 leading-relaxed">
                  Visual donut/bar charts and smart recommendations via Gemini AI with built-in rule-based fallback.
                </p>
              </div>
            </div>
          </div>

          {/* Academic Architecture Specs */}
          <div className="mt-16 bg-white rounded-3xl border border-slate-200 p-8 shadow-xs">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-center md:text-left">
              <div className="flex flex-col items-center md:items-start gap-2">
                <div className="p-3 bg-indigo-50 text-indigo-600 rounded-xl">
                  <Server className="h-6 w-6" />
                </div>
                <h4 className="font-bold text-slate-900 text-sm">Express REST Backend</h4>
                <p className="text-xs text-slate-500">
                  Clean MVC architecture with controllers, token authentication middleware, and validated routes.
                </p>
              </div>

              <div className="flex flex-col items-center md:items-start gap-2">
                <div className="p-3 bg-emerald-50 text-emerald-600 rounded-xl">
                  <ShieldCheck className="h-6 w-6" />
                </div>
                <h4 className="font-bold text-slate-900 text-sm">MySQL Database & SQL Script</h4>
                <p className="text-xs text-slate-500">
                  Full MySQL schema with foreign keys, ON DELETE CASCADE, indexes, and XAMPP phpMyAdmin compatibility.
                </p>
              </div>

              <div className="flex flex-col items-center md:items-start gap-2">
                <div className="p-3 bg-purple-50 text-purple-600 rounded-xl">
                  <Sparkles className="h-6 w-6" />
                </div>
                <h4 className="font-bold text-slate-900 text-sm">Dual AI & Rule Engine</h4>
                <p className="text-xs text-slate-500">
                  Google Gemini 3.8 Flash model combined with an academic rule-based fallback when offline.
                </p>
              </div>
            </div>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t border-slate-200 bg-white py-6">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-slate-500">
          <p>
            Problem Statement 16 – AI Study Planner • BCA 3rd Year Academic Project
          </p>
          <p className="font-mono text-slate-400">
            Node.js • Express • MySQL • React • Tailwind CSS
          </p>
        </div>
      </footer>
    </div>
  );
};
