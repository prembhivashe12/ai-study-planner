import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext.js';
import { api } from '../services/api.js';
import { Subject, Task, StatisticsData } from '../types/index.js';
import { StatCard } from '../components/StatCard.js';
import { DonutChart, HorizontalBarChart, ProgressBar } from '../components/Charts.js';
import {
  BookOpen,
  CheckCircle2,
  Clock,
  AlertTriangle,
  FolderGit2,
  Sparkles,
  Plus,
  ArrowRight,
  Calendar,
  Layers,
  Flame,
} from 'lucide-react';

interface DashboardPageProps {
  onNavigateTab: (tab: string) => void;
  onOpenAddTask: () => void;
  onOpenAddSubject: () => void;
  onEditTask: (task: Task) => void;
}

export const DashboardPage: React.FC<DashboardPageProps> = ({
  onNavigateTab,
  onOpenAddTask,
  onOpenAddSubject,
  onEditTask,
}) => {
  const { user } = useAuth();
  const [stats, setStats] = useState<StatisticsData | null>(null);
  const [recentTasks, setRecentTasks] = useState<Task[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const loadDashboardData = async () => {
    try {
      setIsLoading(true);
      setError(null);
      const [statsRes, tasksRes] = await Promise.all([
        api.statistics.get(),
        api.tasks.getAll(),
      ]);

      if (statsRes.success) setStats(statsRes.statistics);
      if (tasksRes.success) setRecentTasks(tasksRes.tasks.slice(0, 6));
    } catch (err: any) {
      console.error('Dashboard load error:', err);
      setError(err.message || 'Failed to load dashboard data.');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadDashboardData();
  }, []);

  const handleToggleTaskStatus = async (taskId: number, currentStatus: string) => {
    try {
      const nextStatus = currentStatus === 'Completed' ? 'Pending' : 'Completed';
      await api.tasks.updateStatus(taskId, nextStatus as any);
      loadDashboardData();
    } catch (err: any) {
      alert('Failed to update task status: ' + err.message);
    }
  };

  const todayStr = new Date().toISOString().split('T')[0];

  return (
    <div className="space-y-6">
      {/* Welcome Banner */}
      <div className="bg-gradient-to-r from-indigo-900 via-indigo-800 to-blue-800 rounded-3xl p-6 sm:p-8 text-white shadow-md relative overflow-hidden">
        <div className="absolute right-0 top-0 bottom-0 opacity-10 pointer-events-none flex items-center pr-10">
          <BookOpen className="w-80 h-80" />
        </div>

        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="max-w-2xl">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/10 backdrop-blur-md text-indigo-200 text-xs font-semibold mb-3">
              <Flame className="h-3.5 w-3.5 text-amber-400 fill-amber-400" />
              <span>BCA Academic Semester Study Dashboard</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
              Welcome back, {user?.name || 'Student'}! 👋
            </h1>
            <p className="mt-2 text-indigo-100/90 text-sm leading-relaxed">
              "Continuous small efforts lead to outstanding semester grades." Review your priority modules,
              clear upcoming deadlines, and track your overall completion percentage.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            <button
              onClick={onOpenAddTask}
              className="px-4 py-2.5 rounded-xl font-bold text-xs bg-white text-indigo-900 hover:bg-indigo-50 shadow-xs transition-all flex items-center gap-1.5"
            >
              <Plus className="h-4 w-4" />
              <span>Add Study Task</span>
            </button>
            <button
              onClick={() => onNavigateTab('recommendations')}
              className="px-4 py-2.5 rounded-xl font-bold text-xs bg-indigo-500/40 hover:bg-indigo-500/60 text-white border border-white/20 transition-all flex items-center gap-1.5 backdrop-blur-xs"
            >
              <Sparkles className="h-4 w-4 text-amber-300" />
              <span>AI Study Advice</span>
            </button>
          </div>
        </div>
      </div>

      {/* Primary Academic Stat Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 sm:gap-4">
        <StatCard
          title="Total Subjects"
          value={stats?.total_subjects || 0}
          subtitle="Enrolled modules"
          icon={FolderGit2}
          colorScheme="indigo"
          onClick={() => onNavigateTab('subjects')}
        />
        <StatCard
          title="Total Tasks"
          value={stats?.total_tasks || 0}
          subtitle="Syllabus topics"
          icon={BookOpen}
          colorScheme="blue"
          onClick={() => onNavigateTab('tasks')}
        />
        <StatCard
          title="Completed"
          value={stats?.completed_tasks || 0}
          subtitle={`${stats?.completion_percentage || 0}% finished`}
          icon={CheckCircle2}
          colorScheme="emerald"
          onClick={() => onNavigateTab('tasks')}
        />
        <StatCard
          title="Pending"
          value={stats?.pending_tasks || 0}
          subtitle="Needs focus"
          icon={Clock}
          colorScheme="amber"
          onClick={() => onNavigateTab('tasks')}
        />
        <StatCard
          title="Overdue"
          value={stats?.overdue_tasks || 0}
          subtitle="Missed dates"
          icon={AlertTriangle}
          colorScheme="rose"
          onClick={() => onNavigateTab('priority-deadlines')}
        />
        <StatCard
          title="Progress"
          value={`${stats?.completion_percentage || 0}%`}
          subtitle="Overall completion"
          icon={Flame}
          colorScheme="purple"
          onClick={() => onNavigateTab('statistics')}
        />
      </div>

      {/* Main Grid: Visual Status Distribution & Urgent Priorities */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left: Overall Completion Analytics */}
        <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-xs">
          <div className="flex items-center justify-between pb-4 border-b border-slate-100 mb-6">
            <div>
              <h2 className="font-bold text-slate-900 text-sm">Study Task Distribution</h2>
              <p className="text-xs text-slate-400">Current syllabus task statuses</p>
            </div>
            <button
              onClick={() => onNavigateTab('statistics')}
              className="text-xs font-semibold text-indigo-600 hover:text-indigo-800 flex items-center gap-1"
            >
              <span>Full Stats</span>
              <ArrowRight className="h-3.5 w-3.5" />
            </button>
          </div>

          <div className="py-2">
            <DonutChart
              size={180}
              thickness={24}
              centerText={`${stats?.completion_percentage || 0}%`}
              centerSubtext="Completed"
              data={[
                { label: 'Completed', value: stats?.completed_tasks || 0, color: '#10b981' },
                { label: 'In Progress', value: stats?.in_progress_tasks || 0, color: '#6366f1' },
                { label: 'Pending', value: stats?.pending_tasks || 0, color: '#f59e0b' },
                { label: 'Overdue', value: stats?.overdue_tasks || 0, color: '#ef4444' },
              ]}
            />
          </div>

          <div className="mt-6 pt-4 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
            <span>Total Study Hours Logged:</span>
            <span className="font-bold text-slate-900">{stats?.hours?.total || 0} Hours</span>
          </div>
        </div>

        {/* Center / Right: Urgent Attention & Deadlines */}
        <div className="lg:col-span-2 bg-white rounded-3xl border border-slate-200 p-6 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-4 border-b border-slate-100 mb-4">
              <div>
                <h2 className="font-bold text-slate-900 text-sm flex items-center gap-2">
                  <AlertTriangle className="h-4 w-4 text-amber-500" />
                  Urgent Deadlines & High Priority Tasks
                </h2>
                <p className="text-xs text-slate-400">Immediate action required before exams</p>
              </div>
              <button
                onClick={() => onNavigateTab('priority-deadlines')}
                className="text-xs font-semibold text-indigo-600 hover:text-indigo-800 flex items-center gap-1"
              >
                <span>View All Deadlines</span>
                <ArrowRight className="h-3.5 w-3.5" />
              </button>
            </div>

            {/* Task list preview */}
            <div className="space-y-2.5">
              {recentTasks.length === 0 ? (
                <div className="text-center py-10 text-slate-400">
                  <BookOpen className="h-10 w-10 mx-auto text-slate-300 mb-2" />
                  <p className="text-xs">No tasks added yet. Start by adding your first study task!</p>
                  <button
                    onClick={onOpenAddTask}
                    className="mt-3 px-3.5 py-1.5 bg-indigo-600 text-white rounded-xl text-xs font-semibold"
                  >
                    Add Task
                  </button>
                </div>
              ) : (
                recentTasks.slice(0, 4).map((task) => {
                  const isOverdue = task.deadline < todayStr && task.status !== 'Completed';
                  const isDueToday = task.deadline === todayStr;

                  return (
                    <div
                      key={task.id}
                      className="p-3 rounded-2xl border border-slate-200/80 hover:border-slate-300 transition-all flex items-center justify-between gap-3 bg-slate-50/50"
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        <button
                          onClick={() => handleToggleTaskStatus(task.id, task.status)}
                          className={`h-5 w-5 rounded-md border flex items-center justify-center transition-colors ${
                            task.status === 'Completed'
                              ? 'bg-emerald-600 border-emerald-600 text-white'
                              : 'border-slate-300 hover:border-indigo-500 bg-white'
                          }`}
                          title="Click to toggle completion status"
                        >
                          {task.status === 'Completed' && <CheckCircle2 className="h-4 w-4" />}
                        </button>
                        <div className="min-w-0">
                          <p
                            onClick={() => onEditTask(task)}
                            className={`text-xs font-bold truncate cursor-pointer hover:text-indigo-600 ${
                              task.status === 'Completed' ? 'line-through text-slate-400' : 'text-slate-900'
                            }`}
                          >
                            {task.title}
                          </p>
                          <div className="flex items-center gap-2 mt-0.5 text-[11px] text-slate-500">
                            <span
                              className="font-medium px-1.5 py-0.2 rounded text-[10px]"
                              style={{
                                backgroundColor: (task.subject_color || '#3b82f6') + '20',
                                color: task.subject_color || '#3b82f6',
                              }}
                            >
                              {task.subject_name}
                            </span>
                            <span className="flex items-center gap-1 font-mono text-slate-400">
                              <Calendar className="h-3 w-3" />
                              {task.deadline}
                            </span>
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center gap-2 shrink-0">
                        {isOverdue && (
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-red-100 text-red-700">
                            Overdue
                          </span>
                        )}
                        {isDueToday && (
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-800">
                            Due Today
                          </span>
                        )}
                        <span
                          className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                            task.priority === 'High'
                              ? 'bg-red-50 text-red-700 border border-red-200'
                              : task.priority === 'Medium'
                              ? 'bg-amber-50 text-amber-700 border border-amber-200'
                              : 'bg-blue-50 text-blue-700 border border-blue-200'
                          }`}
                        >
                          {task.priority}
                        </span>
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>

          {/* Quick Subject Progress Summary */}
          <div className="mt-4 pt-4 border-t border-slate-100 flex items-center justify-between">
            <span className="text-xs text-slate-500">
              Need help organizing by subject modules?
            </span>
            <button
              onClick={() => onNavigateTab('subject-wise')}
              className="text-xs font-bold text-indigo-600 hover:text-indigo-800 flex items-center gap-1"
            >
              <span>Subject-Wise Planning</span>
              <ArrowRight className="h-3.5 w-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* Subject Wise Progress Bar Highlights */}
      {stats?.subjects && stats.subjects.length > 0 && (
        <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-xs">
          <div className="flex items-center justify-between pb-4 border-b border-slate-100 mb-5">
            <div>
              <h2 className="font-bold text-slate-900 text-sm">Subject Progress Tracking</h2>
              <p className="text-xs text-slate-400">Completion rate per enrolled academic subject</p>
            </div>
            <button
              onClick={onOpenAddSubject}
              className="text-xs font-bold px-3 py-1.5 rounded-xl border border-slate-200 hover:bg-slate-50 text-slate-700 flex items-center gap-1.5 transition-colors"
            >
              <Plus className="h-3.5 w-3.5" />
              <span>Add Subject</span>
            </button>
          </div>

          <HorizontalBarChart
            items={stats.subjects.map((s) => ({
              label: s.name,
              sublabel: s.code || undefined,
              completed: s.completed,
              total: s.total,
              color: s.color,
            }))}
          />
        </div>
      )}
    </div>
  );
};
