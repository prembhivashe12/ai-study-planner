import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext.js';
import { api } from '../services/api.js';
import {
  User,
  Mail,
  GraduationCap,
  Database,
  RefreshCw,
  Download,
  LogOut,
  CheckCircle2,
  AlertCircle,
  FileCode,
} from 'lucide-react';

export const ProfilePage: React.FC = () => {
  const { user, databaseMode, logout, reloadUser } = useAuth();
  const [isResetting, setIsResetting] = useState(false);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleResetDemoData = async () => {
    if (!window.confirm('Reset and reload standard BCA 3rd Year sample syllabus data?')) return;
    try {
      setIsResetting(true);
      setError(null);
      const res = await api.auth.resetDemoData();
      if (res.success) {
        setSuccessMessage('BCA demo syllabus (Java, DBMS, Web Dev, Networks, Python) reloaded successfully!');
        await reloadUser();
      }
    } catch (err: any) {
      setError(err.message || 'Failed to reload demo data.');
    } finally {
      setIsResetting(false);
    }
  };

  const handleDownloadSchemaSql = () => {
    const link = document.createElement('a');
    link.href = '/database/schema.sql';
    link.download = 'schema.sql';
    link.click();
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Header */}
      <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900 flex items-center gap-2">
            <User className="h-5 w-5 text-indigo-600" />
            Student Profile & Academic Settings
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Manage your account details and configure academic database preferences
          </p>
        </div>

        <button
          onClick={logout}
          className="px-4 py-2 rounded-xl border border-red-200 bg-red-50 text-red-700 hover:bg-red-100 text-xs font-bold transition-colors flex items-center gap-2 self-start sm:self-auto"
        >
          <LogOut className="h-4 w-4" />
          <span>Sign Out</span>
        </button>
      </div>

      {successMessage && (
        <div className="p-4 bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs rounded-2xl flex items-center gap-2">
          <CheckCircle2 className="h-4 w-4 text-emerald-600 shrink-0" />
          <span>{successMessage}</span>
        </div>
      )}

      {error && (
        <div className="p-4 bg-red-50 border border-red-200 text-red-700 text-xs rounded-2xl flex items-center gap-2">
          <AlertCircle className="h-4 w-4 text-red-600 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {/* Student Details Card */}
      <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-xs space-y-6">
        <h2 className="text-sm font-bold text-slate-900 pb-3 border-b border-slate-100">
          Enrolled Student Credentials
        </h2>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-5">
          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-100">
            <div className="flex items-center gap-2 text-slate-400 mb-1 text-xs">
              <User className="h-4 w-4" />
              <span>Full Name</span>
            </div>
            <p className="text-sm font-bold text-slate-900">{user?.name || '-'}</p>
          </div>

          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-100">
            <div className="flex items-center gap-2 text-slate-400 mb-1 text-xs">
              <Mail className="h-4 w-4" />
              <span>Academic Email</span>
            </div>
            <p className="text-sm font-bold text-slate-900 truncate">{user?.email || '-'}</p>
          </div>

          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-100">
            <div className="flex items-center gap-2 text-slate-400 mb-1 text-xs">
              <GraduationCap className="h-4 w-4" />
              <span>Class / Course</span>
            </div>
            <p className="text-sm font-bold text-slate-900">{user?.course || 'BCA 3rd Year'}</p>
          </div>
        </div>
      </div>

      {/* Academic Demonstration & Database Environment Card */}
      <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-xs space-y-5">
        <h2 className="text-sm font-bold text-slate-900 pb-3 border-b border-slate-100">
          Academic Database & Examiner Controls
        </h2>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div className="p-4 rounded-2xl border border-slate-200/90 bg-slate-50/50 space-y-2">
            <div className="flex items-center gap-2">
              <Database className="h-4 w-4 text-indigo-600" />
              <span className="text-xs font-bold text-slate-900">Database Engine</span>
            </div>
            <p className="text-xs text-slate-600">
              Active Mode: <strong className="text-indigo-700">{databaseMode}</strong>
            </p>
            <p className="text-[11px] text-slate-400 leading-relaxed">
              Compatible with local MySQL (XAMPP / phpMyAdmin on port 3306) and runs seamlessly on persistent relational storage.
            </p>
          </div>

          <div className="p-4 rounded-2xl border border-slate-200/90 bg-slate-50/50 space-y-2">
            <div className="flex items-center gap-2">
              <FileCode className="h-4 w-4 text-emerald-600" />
              <span className="text-xs font-bold text-slate-900">MySQL Schema Script</span>
            </div>
            <p className="text-xs text-slate-600">
              File: <code className="font-mono bg-white px-1.5 py-0.5 rounded border">database/schema.sql</code>
            </p>
            <p className="text-[11px] text-slate-400 leading-relaxed">
              Contains complete DDL statements, Foreign Keys, ON DELETE CASCADE, and seed records for phpMyAdmin import.
            </p>
          </div>
        </div>

        {/* Action buttons */}
        <div className="pt-2 flex flex-wrap items-center gap-3">
          <a
            href="/api/download-zip"
            download="ai-study-planner.zip"
            className="px-4 py-2 rounded-xl text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 shadow-xs transition-colors flex items-center gap-2"
          >
            <Download className="h-4 w-4" />
            <span>Download Project ZIP (Complete Code)</span>
          </a>

          <button
            onClick={handleResetDemoData}
            disabled={isResetting}
            className="px-4 py-2 rounded-xl text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-700 shadow-xs transition-colors flex items-center gap-2 disabled:opacity-50"
          >
            <RefreshCw className={`h-4 w-4 ${isResetting ? 'animate-spin' : ''}`} />
            <span>{isResetting ? 'Reloading...' : 'Reload Sample BCA Syllabus Data'}</span>
          </button>
        </div>
      </div>

      {/* Academic Project Viva Summary */}
      <div className="bg-slate-50 rounded-3xl border border-slate-200 p-6 text-xs text-slate-600 space-y-2">
        <h4 className="font-bold text-slate-900">
          Problem Statement 16 Viva Quick Reference:
        </h4>
        <ul className="list-disc list-inside space-y-1 text-slate-600">
          <li><strong>Architecture:</strong> Client (React 19 + Tailwind CSS) &lt;-&gt; Express REST API &lt;-&gt; MySQL Relational Database</li>
          <li><strong>Security:</strong> Passwords hashed with bcrypt; authentication verified with JSON Web Tokens (JWT) in Bearer headers</li>
          <li><strong>AI Engine:</strong> Server-side Google Gemini 3.8 Flash model via <code>@google/genai</code> SDK with automatic rule-based fallback</li>
          <li><strong>Data Isolation:</strong> All SQL queries filter strictly by <code>user_id = ?</code> to ensure student privacy</li>
        </ul>
      </div>
    </div>
  );
};
