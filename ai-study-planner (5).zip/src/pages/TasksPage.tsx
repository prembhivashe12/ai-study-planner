import React, { useState, useEffect } from 'react';
import { api } from '../services/api.js';
import { Task, Subject, Priority, TaskStatus } from '../types/index.js';
import {
  Plus,
  Search,
  Filter,
  ArrowUpDown,
  CheckCircle2,
  Clock,
  Calendar,
  Edit2,
  Trash2,
  BookOpen,
  AlertTriangle,
} from 'lucide-react';

interface TasksPageProps {
  onOpenAddTask: () => void;
  onEditTask: (task: Task) => void;
  onDeleteTask: (task: Task) => void;
  subjects: Subject[];
}

export const TasksPage: React.FC<TasksPageProps> = ({
  onOpenAddTask,
  onEditTask,
  onDeleteTask,
  subjects,
}) => {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [search, setSearch] = useState('');
  const [selectedSubject, setSelectedSubject] = useState<string>('all');
  const [selectedPriority, setSelectedPriority] = useState<string>('all');
  const [selectedStatus, setSelectedStatus] = useState<string>('all');
  const [selectedDeadline, setSelectedDeadline] = useState<string>('all');
  const [sortBy, setSortBy] = useState<string>('deadline-asc');
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const loadTasks = async () => {
    try {
      setIsLoading(true);
      setError(null);
      const res = await api.tasks.getAll();
      if (res.success) setTasks(res.tasks);
    } catch (err: any) {
      setError(err.message || 'Failed to load study tasks.');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadTasks();
  }, []);

  const handleStatusChange = async (taskId: number, newStatus: TaskStatus) => {
    try {
      await api.tasks.updateStatus(taskId, newStatus);
      setTasks((prev) =>
        prev.map((t) => (t.id === taskId ? { ...t, status: newStatus } : t))
      );
    } catch (err: any) {
      alert('Failed to update task status: ' + err.message);
    }
  };

  const todayStr = new Date().toISOString().split('T')[0];
  const tomorrow = new Date();
  tomorrow.setDate(tomorrow.getDate() + 1);
  const tomorrowStr = tomorrow.toISOString().split('T')[0];

  // Client-side filtering & sorting
  const filteredTasks = tasks.filter((t) => {
    if (search.trim()) {
      const q = search.toLowerCase();
      const matchesTitle = t.title.toLowerCase().includes(q);
      const matchesDesc = t.description?.toLowerCase().includes(q);
      const matchesSubject = t.subject_name?.toLowerCase().includes(q);
      if (!matchesTitle && !matchesDesc && !matchesSubject) return false;
    }

    if (selectedSubject !== 'all' && t.subject_id !== Number(selectedSubject)) {
      return false;
    }

    if (selectedPriority !== 'all' && t.priority !== selectedPriority) {
      return false;
    }

    if (selectedStatus !== 'all' && t.status !== selectedStatus) {
      return false;
    }

    if (selectedDeadline !== 'all') {
      if (selectedDeadline === 'overdue' && !(t.deadline < todayStr && t.status !== 'Completed'))
        return false;
      if (selectedDeadline === 'today' && t.deadline !== todayStr) return false;
      if (selectedDeadline === 'tomorrow' && t.deadline !== tomorrowStr) return false;
      if (selectedDeadline === 'upcoming' && t.deadline <= todayStr) return false;
    }

    return true;
  });

  const sortedTasks = [...filteredTasks].sort((a, b) => {
    if (sortBy === 'deadline-asc') {
      return new Date(a.deadline).getTime() - new Date(b.deadline).getTime();
    }
    if (sortBy === 'deadline-desc') {
      return new Date(b.deadline).getTime() - new Date(a.deadline).getTime();
    }
    if (sortBy === 'priority') {
      const pWeights = { High: 3, Medium: 2, Low: 1 };
      return pWeights[b.priority] - pWeights[a.priority];
    }
    if (sortBy === 'hours') {
      return Number(b.estimated_hours) - Number(a.estimated_hours);
    }
    return 0;
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-6 rounded-3xl border border-slate-200 shadow-xs">
        <div>
          <h1 className="text-xl font-bold text-slate-900 flex items-center gap-2">
            <BookOpen className="h-5 w-5 text-indigo-600" />
            Study Task Management
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Add, edit, filter, and track all your academic syllabus modules
          </p>
        </div>
        <button
          onClick={onOpenAddTask}
          className="px-4 py-2.5 rounded-xl font-bold text-xs text-white bg-indigo-600 hover:bg-indigo-700 shadow-xs transition-all flex items-center gap-2 self-start sm:self-auto"
        >
          <Plus className="h-4 w-4" />
          <span>Add Study Task</span>
        </button>
      </div>

      {/* Search & Filters Bar */}
      <div className="bg-white p-5 rounded-3xl border border-slate-200 shadow-xs space-y-3">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
          {/* Search Box */}
          <div className="relative lg:col-span-2">
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search tasks, descriptions, or subjects..."
              className="w-full pl-9 pr-3 py-2 text-xs border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-hidden"
            />
            <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
          </div>

          {/* Subject Filter */}
          <div>
            <select
              value={selectedSubject}
              onChange={(e) => setSelectedSubject(e.target.value)}
              className="w-full px-3 py-2 text-xs border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-hidden bg-white"
            >
              <option value="all">All Subjects</option>
              {subjects.map((sub) => (
                <option key={sub.id} value={sub.id}>
                  {sub.name}
                </option>
              ))}
            </select>
          </div>

          {/* Priority Filter */}
          <div>
            <select
              value={selectedPriority}
              onChange={(e) => setSelectedPriority(e.target.value)}
              className="w-full px-3 py-2 text-xs border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-hidden bg-white"
            >
              <option value="all">All Priorities</option>
              <option value="High">High Priority</option>
              <option value="Medium">Medium Priority</option>
              <option value="Low">Low Priority</option>
            </select>
          </div>

          {/* Status Filter */}
          <div>
            <select
              value={selectedStatus}
              onChange={(e) => setSelectedStatus(e.target.value)}
              className="w-full px-3 py-2 text-xs border border-slate-300 rounded-xl focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-hidden bg-white"
            >
              <option value="all">All Statuses</option>
              <option value="Pending">Pending</option>
              <option value="In Progress">In Progress</option>
              <option value="Completed">Completed</option>
            </select>
          </div>
        </div>

        {/* Secondary Filter Row: Deadline & Sort */}
        <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-slate-100 text-xs">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-slate-400 font-medium">Deadline:</span>
            {[
              { id: 'all', label: 'All' },
              { id: 'overdue', label: 'Overdue' },
              { id: 'today', label: 'Due Today' },
              { id: 'tomorrow', label: 'Due Tomorrow' },
              { id: 'upcoming', label: 'Upcoming' },
            ].map((f) => (
              <button
                key={f.id}
                onClick={() => setSelectedDeadline(f.id)}
                className={`px-2.5 py-1 rounded-lg font-semibold transition-colors ${
                  selectedDeadline === f.id
                    ? 'bg-indigo-600 text-white'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                {f.label}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-2">
            <ArrowUpDown className="h-3.5 w-3.5 text-slate-400" />
            <span className="text-slate-400 font-medium">Sort By:</span>
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value)}
              className="px-2 py-1 text-xs border border-slate-300 rounded-lg outline-hidden bg-white"
            >
              <option value="deadline-asc">Deadline (Earliest First)</option>
              <option value="deadline-desc">Deadline (Latest First)</option>
              <option value="priority">Priority (High to Low)</option>
              <option value="hours">Estimated Study Hours</option>
            </select>
          </div>
        </div>
      </div>

      {error && (
        <div className="p-4 bg-red-50 border border-red-200 text-red-700 text-xs rounded-2xl">
          {error}
        </div>
      )}

      {/* Tasks Table / Card List */}
      <div className="bg-white rounded-3xl border border-slate-200 shadow-xs overflow-hidden">
        {sortedTasks.length === 0 ? (
          <div className="p-12 text-center text-slate-400">
            <BookOpen className="h-10 w-10 mx-auto text-slate-300 mb-2" />
            <p className="text-xs font-semibold text-slate-600">No study tasks match your filters</p>
            <p className="text-xs text-slate-400 mt-1">Try resetting the search keyword or filter dropdowns.</p>
          </div>
        ) : (
          <div className="divide-y divide-slate-100">
            {sortedTasks.map((task) => {
              const isOverdue = task.deadline < todayStr && task.status !== 'Completed';
              const isDueToday = task.deadline === todayStr;
              const isDueTomorrow = task.deadline === tomorrowStr;

              return (
                <div
                  key={task.id}
                  className="p-4 sm:p-5 hover:bg-slate-50/70 transition-colors flex flex-col sm:flex-row sm:items-center justify-between gap-4"
                >
                  {/* Left: Checkbox + Title + Metadata */}
                  <div className="flex items-start gap-3.5 min-w-0">
                    <button
                      onClick={() =>
                        handleStatusChange(
                          task.id,
                          task.status === 'Completed' ? 'Pending' : 'Completed'
                        )
                      }
                      className={`h-5 w-5 mt-0.5 rounded-md border flex items-center justify-center transition-colors shrink-0 ${
                        task.status === 'Completed'
                          ? 'bg-emerald-600 border-emerald-600 text-white'
                          : 'border-slate-300 hover:border-indigo-500 bg-white'
                      }`}
                      title="Toggle completion status"
                    >
                      {task.status === 'Completed' && <CheckCircle2 className="h-4 w-4" />}
                    </button>

                    <div className="min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <h3
                          onClick={() => onEditTask(task)}
                          className={`text-sm font-bold cursor-pointer hover:text-indigo-600 transition-colors ${
                            task.status === 'Completed'
                              ? 'line-through text-slate-400'
                              : 'text-slate-900'
                          }`}
                        >
                          {task.title}
                        </h3>

                        {/* Subject Badge */}
                        <span
                          className="text-[10px] font-semibold px-2 py-0.5 rounded-full"
                          style={{
                            backgroundColor: (task.subject_color || '#3b82f6') + '20',
                            color: task.subject_color || '#3b82f6',
                          }}
                        >
                          {task.subject_name}
                        </span>

                        {/* Priority Badge */}
                        <span
                          className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                            task.priority === 'High'
                              ? 'bg-red-50 text-red-700 border border-red-200'
                              : task.priority === 'Medium'
                              ? 'bg-amber-50 text-amber-700 border border-amber-200'
                              : 'bg-blue-50 text-blue-700 border border-blue-200'
                          }`}
                        >
                          {task.priority} Priority
                        </span>
                      </div>

                      {task.description && (
                        <p className="mt-1 text-xs text-slate-500 line-clamp-1">
                          {task.description}
                        </p>
                      )}

                      {/* Dates & Hours row */}
                      <div className="mt-2 flex items-center gap-4 text-xs text-slate-500 flex-wrap">
                        <span className="flex items-center gap-1 font-mono">
                          <Calendar className="h-3.5 w-3.5 text-slate-400" />
                          <span>Deadline: {task.deadline}</span>
                        </span>

                        <span className="flex items-center gap-1 font-mono">
                          <Clock className="h-3.5 w-3.5 text-slate-400" />
                          <span>{task.estimated_hours} hrs</span>
                        </span>

                        {/* Deadline badges */}
                        {isOverdue && (
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-red-100 text-red-700 flex items-center gap-1">
                            <AlertTriangle className="h-3 w-3" />
                            Overdue
                          </span>
                        )}
                        {isDueToday && (
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-800">
                            Due Today
                          </span>
                        )}
                        {isDueTomorrow && (
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-blue-100 text-blue-800">
                            Due Tomorrow
                          </span>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Right: Status selector & Action buttons */}
                  <div className="flex items-center gap-3 shrink-0 self-end sm:self-center">
                    <select
                      value={task.status}
                      onChange={(e) => handleStatusChange(task.id, e.target.value as TaskStatus)}
                      className={`text-xs font-semibold px-2.5 py-1 rounded-xl border outline-hidden transition-colors ${
                        task.status === 'Completed'
                          ? 'bg-emerald-50 border-emerald-200 text-emerald-800'
                          : task.status === 'In Progress'
                          ? 'bg-indigo-50 border-indigo-200 text-indigo-800'
                          : 'bg-amber-50 border-amber-200 text-amber-800'
                      }`}
                    >
                      <option value="Pending">Pending</option>
                      <option value="In Progress">In Progress</option>
                      <option value="Completed">Completed</option>
                    </select>

                    <button
                      onClick={() => onEditTask(task)}
                      className="p-1.5 text-slate-400 hover:text-indigo-600 rounded-lg hover:bg-slate-100 transition-colors"
                      title="Edit task"
                    >
                      <Edit2 className="h-4 w-4" />
                    </button>

                    <button
                      onClick={() => onDeleteTask(task)}
                      className="p-1.5 text-slate-400 hover:text-red-600 rounded-lg hover:bg-red-50 transition-colors"
                      title="Delete task"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
