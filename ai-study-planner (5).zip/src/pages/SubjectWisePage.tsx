import React, { useState, useEffect } from 'react';
import { api } from '../services/api.js';
import { Subject, Task, TaskStatus } from '../types/index.js';
import { Layers, Plus, CheckCircle2, Clock, Calendar, ChevronDown, ChevronUp, BookOpen } from 'lucide-react';
import { ProgressBar } from '../components/Charts.js';

interface SubjectWisePageProps {
  onOpenAddTaskForSubject: (subjectId: number) => void;
  onEditTask: (task: Task) => void;
  initialSelectedSubjectId?: number | null;
}

export const SubjectWisePage: React.FC<SubjectWisePageProps> = ({
  onOpenAddTaskForSubject,
  onEditTask,
  initialSelectedSubjectId,
}) => {
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [tasks, setTasks] = useState<Task[]>([]);
  const [activeFilter, setActiveFilter] = useState<number | 'all'>(
    initialSelectedSubjectId || 'all'
  );
  const [expandedSubjectIds, setExpandedSubjectIds] = useState<Set<number>>(new Set());
  const [isLoading, setIsLoading] = useState(true);

  const loadData = async () => {
    try {
      setIsLoading(true);
      const [subRes, taskRes] = await Promise.all([
        api.subjects.getAll(),
        api.tasks.getAll(),
      ]);

      if (subRes.success) {
        setSubjects(subRes.subjects);
        // Expand all subjects by default for clear visualization
        setExpandedSubjectIds(new Set(subRes.subjects.map((s) => s.id)));
      }
      if (taskRes.success) setTasks(taskRes.tasks);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const toggleExpand = (subId: number) => {
    setExpandedSubjectIds((prev) => {
      const next = new Set(prev);
      if (next.has(subId)) next.delete(subId);
      else next.add(subId);
      return next;
    });
  };

  const handleStatusChange = async (taskId: number, newStatus: TaskStatus) => {
    try {
      await api.tasks.updateStatus(taskId, newStatus);
      setTasks((prev) =>
        prev.map((t) => (t.id === taskId ? { ...t, status: newStatus } : t))
      );
    } catch (err: any) {
      alert('Status update failed: ' + err.message);
    }
  };

  const visibleSubjects =
    activeFilter === 'all'
      ? subjects
      : subjects.filter((s) => s.id === activeFilter);

  const todayStr = new Date().toISOString().split('T')[0];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900 flex items-center gap-2">
            <Layers className="h-5 w-5 text-indigo-600" />
            Subject-Wise Study Planning
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Group syllabus topics under their parent subjects to maintain balanced exam preparation
          </p>
        </div>

        {/* Filter Pills */}
        <div className="flex items-center gap-1.5 flex-wrap">
          <button
            onClick={() => setActiveFilter('all')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-colors ${
              activeFilter === 'all'
                ? 'bg-indigo-600 text-white shadow-xs'
                : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
            }`}
          >
            All Subjects
          </button>
          {subjects.map((sub) => (
            <button
              key={sub.id}
              onClick={() => setActiveFilter(sub.id)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-colors flex items-center gap-1.5 ${
                activeFilter === sub.id
                  ? 'bg-slate-900 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              <span
                className="h-2 w-2 rounded-full"
                style={{ backgroundColor: sub.color || '#3b82f6' }}
              />
              <span>{sub.code || sub.name}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Subject Groups */}
      <div className="space-y-5">
        {visibleSubjects.map((sub) => {
          const subTasks = tasks.filter((t) => t.subject_id === sub.id);
          const completedCount = subTasks.filter((t) => t.status === 'Completed').length;
          const totalCount = subTasks.length;
          const pct = totalCount > 0 ? Math.round((completedCount / totalCount) * 100) : 0;
          const isExpanded = expandedSubjectIds.has(sub.id);

          return (
            <div
              key={sub.id}
              className="bg-white rounded-3xl border border-slate-200 shadow-xs overflow-hidden transition-all"
            >
              {/* Subject Group Header */}
              <div
                className="p-5 sm:p-6 bg-slate-50/70 border-b border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-4 cursor-pointer"
                onClick={() => toggleExpand(sub.id)}
              >
                <div className="flex items-center gap-3.5">
                  <div
                    className="h-10 w-10 rounded-2xl flex items-center justify-center font-bold text-white shadow-xs"
                    style={{ backgroundColor: sub.color || '#3b82f6' }}
                  >
                    {sub.name.charAt(0).toUpperCase()}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h2 className="font-bold text-slate-900 text-base">{sub.name}</h2>
                      {sub.code && (
                        <span className="font-mono text-[11px] px-2 py-0.5 rounded bg-white border border-slate-200 text-slate-700 font-semibold">
                          {sub.code}
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-slate-500 mt-0.5 line-clamp-1">
                      {sub.description || 'Core syllabus coursework module'}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-4 self-end sm:self-center" onClick={(e) => e.stopPropagation()}>
                  <div className="text-right min-w-[120px]">
                    <span className="text-xs font-bold text-slate-800">
                      {completedCount} / {totalCount} Completed
                    </span>
                    <div className="w-28 mt-1">
                      <ProgressBar value={completedCount} max={totalCount || 1} color={sub.color} />
                    </div>
                  </div>

                  <button
                    onClick={() => onOpenAddTaskForSubject(sub.id)}
                    className="px-3 py-1.5 rounded-xl font-bold text-xs bg-indigo-600 hover:bg-indigo-700 text-white shadow-xs transition-colors flex items-center gap-1.5"
                  >
                    <Plus className="h-3.5 w-3.5" />
                    <span className="hidden sm:inline">Add Task</span>
                  </button>

                  <button
                    onClick={() => toggleExpand(sub.id)}
                    className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-200/60"
                  >
                    {isExpanded ? <ChevronUp className="h-5 w-5" /> : <ChevronDown className="h-5 w-5" />}
                  </button>
                </div>
              </div>

              {/* Tasks under this Subject */}
              {isExpanded && (
                <div className="p-4 sm:p-6 divide-y divide-slate-100">
                  {subTasks.length === 0 ? (
                    <div className="py-8 text-center text-slate-400">
                      <BookOpen className="h-8 w-8 mx-auto text-slate-300 mb-1" />
                      <p className="text-xs">No tasks added for {sub.name} yet.</p>
                      <button
                        onClick={() => onOpenAddTaskForSubject(sub.id)}
                        className="mt-2 text-xs font-bold text-indigo-600 hover:underline"
                      >
                        + Add first module task
                      </button>
                    </div>
                  ) : (
                    subTasks.map((task) => {
                      const isOverdue = task.deadline < todayStr && task.status !== 'Completed';

                      return (
                        <div
                          key={task.id}
                          className="py-3.5 flex items-center justify-between gap-4 first:pt-0 last:pb-0"
                        >
                          <div className="flex items-center gap-3 min-w-0">
                            <button
                              onClick={() =>
                                handleStatusChange(
                                  task.id,
                                  task.status === 'Completed' ? 'Pending' : 'Completed'
                                )
                              }
                              className={`h-5 w-5 rounded-md border flex items-center justify-center transition-colors shrink-0 ${
                                task.status === 'Completed'
                                  ? 'bg-emerald-600 border-emerald-600 text-white'
                                  : 'border-slate-300 hover:border-indigo-500 bg-white'
                              }`}
                            >
                              {task.status === 'Completed' && <CheckCircle2 className="h-4 w-4" />}
                            </button>

                            <div className="min-w-0">
                              <p
                                onClick={() => onEditTask(task)}
                                className={`text-xs font-bold cursor-pointer hover:text-indigo-600 transition-colors ${
                                  task.status === 'Completed'
                                    ? 'line-through text-slate-400'
                                    : 'text-slate-900'
                                }`}
                              >
                                {task.title}
                              </p>
                              {task.description && (
                                <p className="text-[11px] text-slate-500 truncate max-w-md">
                                  {task.description}
                                </p>
                              )}
                            </div>
                          </div>

                          <div className="flex items-center gap-3 shrink-0">
                            <span className="text-xs font-mono text-slate-400 hidden sm:flex items-center gap-1">
                              <Calendar className="h-3 w-3" />
                              {task.deadline}
                            </span>

                            <span
                              className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                                task.priority === 'High'
                                  ? 'bg-red-50 text-red-700 border border-red-200'
                                  : task.priority === 'Medium'
                                  ? 'bg-amber-50 text-amber-700 border border-amber-200'
                                  : 'bg-blue-50 text-blue-700 border border-blue-200'
                              }`}
                            >
                              {task.priority}
                            </span>

                            <select
                              value={task.status}
                              onChange={(e) =>
                                handleStatusChange(task.id, e.target.value as TaskStatus)
                              }
                              className="text-[11px] font-semibold px-2 py-0.5 rounded-lg border border-slate-200 bg-white"
                            >
                              <option value="Pending">Pending</option>
                              <option value="In Progress">In Progress</option>
                              <option value="Completed">Completed</option>
                            </select>
                          </div>
                        </div>
                      );
                    })
                  )}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};
