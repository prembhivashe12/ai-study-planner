export type Priority = 'High' | 'Medium' | 'Low';
export type TaskStatus = 'Pending' | 'In Progress' | 'Completed';

export interface User {
  id: number;
  name: string;
  email: string;
  course?: string;
  created_at?: string;
}

export interface Subject {
  id: number;
  user_id: number;
  name: string;
  code: string | null;
  description: string | null;
  color: string;
  created_at: string;
}

export interface Task {
  id: number;
  user_id: number;
  subject_id: number;
  title: string;
  description: string | null;
  priority: Priority;
  status: TaskStatus;
  start_date: string;
  deadline: string;
  estimated_hours: number;
  created_at: string;
  updated_at: string;
  subject_name?: string;
  subject_color?: string;
  subject_code?: string;
}

export interface SubjectStatistic {
  id: number;
  name: string;
  code: string | null;
  color: string;
  total: number;
  completed: number;
  inProgress: number;
  pending: number;
  overdue: number;
  hours: number;
  completionPercentage: number;
}

export interface StatisticsData {
  total_subjects: number;
  total_tasks: number;
  completed_tasks: number;
  in_progress_tasks: number;
  pending_tasks: number;
  overdue_tasks: number;
  completion_percentage: number;
  priority_breakdown: {
    high: number;
    medium: number;
    low: number;
  };
  deadline_breakdown: {
    overdue: number;
    due_today: number;
    due_tomorrow: number;
    upcoming: number;
  };
  hours: {
    total: number;
    completed: number;
    pending: number;
  };
  subjects: SubjectStatistic[];
}

export interface StudyRecommendation {
  id: string;
  category: 'Urgent' | 'Subject Focus' | 'Schedule Optimization' | 'Revision' | 'Wellbeing';
  title: string;
  recommendation: string;
  actionableStep: string;
  priorityLevel: 'High' | 'Medium' | 'Low';
  targetSubject?: string;
  suggestedHours?: number;
}

export interface DailyPlanItem {
  day: string;
  focusSubject: string;
  targetTasks: string[];
  allocatedHours: number;
}

export interface RecommendationData {
  source: string;
  generatedAt: string;
  studentSummary: string;
  recommendations: StudyRecommendation[];
  dailyStudyPlan: DailyPlanItem[];
}
