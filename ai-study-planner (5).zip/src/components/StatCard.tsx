import React from 'react';
import { LucideIcon } from 'lucide-react';

interface StatCardProps {
  title: string;
  value: string | number;
  subtitle?: string;
  icon: LucideIcon;
  colorScheme?: 'indigo' | 'emerald' | 'amber' | 'rose' | 'purple' | 'blue';
  onClick?: () => void;
}

export const StatCard: React.FC<StatCardProps> = ({
  title,
  value,
  subtitle,
  icon: Icon,
  colorScheme = 'indigo',
  onClick,
}) => {
  const schemeStyles = {
    indigo: {
      bg: 'bg-indigo-50/60 border-indigo-100',
      iconBg: 'bg-indigo-600 text-white',
      valueText: 'text-indigo-950',
    },
    emerald: {
      bg: 'bg-emerald-50/60 border-emerald-100',
      iconBg: 'bg-emerald-600 text-white',
      valueText: 'text-emerald-950',
    },
    amber: {
      bg: 'bg-amber-50/60 border-amber-100',
      iconBg: 'bg-amber-500 text-white',
      valueText: 'text-amber-950',
    },
    rose: {
      bg: 'bg-rose-50/60 border-rose-100',
      iconBg: 'bg-rose-600 text-white',
      valueText: 'text-rose-950',
    },
    purple: {
      bg: 'bg-purple-50/60 border-purple-100',
      iconBg: 'bg-purple-600 text-white',
      valueText: 'text-purple-950',
    },
    blue: {
      bg: 'bg-blue-50/60 border-blue-100',
      iconBg: 'bg-blue-600 text-white',
      valueText: 'text-blue-950',
    },
  }[colorScheme];

  return (
    <div
      onClick={onClick}
      className={`rounded-2xl border p-5 transition-all bg-white shadow-xs ${
        onClick ? 'cursor-pointer hover:shadow-md hover:border-slate-300' : ''
      }`}
    >
      <div className="flex items-center justify-between">
        <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">{title}</span>
        <div className={`p-2.5 rounded-xl ${schemeStyles.iconBg}`}>
          <Icon className="h-5 w-5" />
        </div>
      </div>
      <div className="mt-3">
        <p className={`text-3xl font-extrabold tracking-tight ${schemeStyles.valueText}`}>{value}</p>
        {subtitle && <p className="mt-1 text-xs text-slate-500">{subtitle}</p>}
      </div>
    </div>
  );
};
