import React from 'react';

interface DonutSlice {
  label: string;
  value: number;
  color: string;
}

export const DonutChart: React.FC<{
  data: DonutSlice[];
  size?: number;
  thickness?: number;
  centerText?: string;
  centerSubtext?: string;
}> = ({ data, size = 200, thickness = 28, centerText, centerSubtext }) => {
  const total = data.reduce((sum, item) => sum + item.value, 0);
  const radius = size / 2;
  const normalizedRadius = radius - thickness / 2;
  const circumference = 2 * Math.PI * normalizedRadius;

  let currentOffset = 0;

  return (
    <div className="flex flex-col sm:flex-row items-center justify-center gap-6">
      <div className="relative" style={{ width: size, height: size }}>
        <svg width={size} height={size} className="rotate-[-90deg]">
          {/* Background track */}
          <circle
            cx={radius}
            cy={radius}
            r={normalizedRadius}
            fill="transparent"
            stroke="#f1f5f9"
            strokeWidth={thickness}
          />
          {/* Data slices */}
          {total > 0 &&
            data.map((slice, i) => {
              const strokeDasharray = `${(slice.value / total) * circumference} ${circumference}`;
              const strokeDashoffset = -currentOffset;
              currentOffset += (slice.value / total) * circumference;

              return (
                <circle
                  key={i}
                  cx={radius}
                  cy={radius}
                  r={normalizedRadius}
                  fill="transparent"
                  stroke={slice.color}
                  strokeWidth={thickness}
                  strokeDasharray={strokeDasharray}
                  strokeDashoffset={strokeDashoffset}
                  strokeLinecap="round"
                  className="transition-all duration-500 hover:opacity-85"
                />
              );
            })}
        </svg>

        {/* Center label */}
        <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
          {centerText && <span className="text-2xl font-black text-slate-800">{centerText}</span>}
          {centerSubtext && <span className="text-xs font-medium text-slate-400">{centerSubtext}</span>}
        </div>
      </div>

      {/* Legend */}
      <div className="flex flex-col gap-2.5 min-w-[140px]">
        {data.map((item, idx) => {
          const pct = total > 0 ? Math.round((item.value / total) * 100) : 0;
          return (
            <div key={idx} className="flex items-center justify-between text-xs">
              <div className="flex items-center gap-2">
                <span className="h-3 w-3 rounded-full" style={{ backgroundColor: item.color }} />
                <span className="font-medium text-slate-700">{item.label}</span>
              </div>
              <span className="font-semibold text-slate-900 ml-3">
                {item.value} <span className="text-slate-400 font-normal">({pct}%)</span>
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
};

interface BarChartItem {
  label: string;
  sublabel?: string;
  completed: number;
  total: number;
  color?: string;
}

export const HorizontalBarChart: React.FC<{ items: BarChartItem[] }> = ({ items }) => {
  return (
    <div className="space-y-4">
      {items.map((item, idx) => {
        const percentage = item.total > 0 ? Math.round((item.completed / item.total) * 100) : 0;
        const color = item.color || '#4f46e5';

        return (
          <div key={idx} className="space-y-1.5">
            <div className="flex items-center justify-between text-xs">
              <div className="flex items-center gap-2">
                <span className="font-semibold text-slate-800">{item.label}</span>
                {item.sublabel && (
                  <span className="text-[11px] px-1.5 py-0.5 rounded bg-slate-100 text-slate-600 font-mono">
                    {item.sublabel}
                  </span>
                )}
              </div>
              <div className="text-right">
                <span className="font-bold text-slate-900">{percentage}%</span>
                <span className="text-slate-400 ml-1.5 font-normal">
                  ({item.completed}/{item.total} tasks)
                </span>
              </div>
            </div>
            <div className="h-3 w-full bg-slate-100 rounded-full overflow-hidden p-0.5">
              <div
                className="h-full rounded-full transition-all duration-500"
                style={{
                  width: `${percentage}%`,
                  backgroundColor: color,
                }}
              />
            </div>
          </div>
        );
      })}
    </div>
  );
};

export const ProgressBar: React.FC<{
  value: number;
  max?: number;
  color?: string;
  heightClass?: string;
}> = ({ value, max = 100, color = '#4f46e5', heightClass = 'h-2' }) => {
  const percentage = Math.min(100, Math.max(0, Math.round((value / max) * 100)));
  return (
    <div className={`w-full bg-slate-100 rounded-full overflow-hidden ${heightClass}`}>
      <div
        className="h-full rounded-full transition-all duration-300"
        style={{ width: `${percentage}%`, backgroundColor: color }}
      />
    </div>
  );
};
