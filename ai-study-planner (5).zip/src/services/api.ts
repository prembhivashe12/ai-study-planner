import {
  Subject,
  Task,
  TaskStatus,
  StatisticsData,
  RecommendationData,
  User,
} from '../types/index.js';

const TOKEN_KEY = 'ai_study_planner_token';

export const getStoredToken = (): string | null => {
  return localStorage.getItem(TOKEN_KEY);
};

export const setStoredToken = (token: string): void => {
  localStorage.setItem(TOKEN_KEY, token);
};

export const removeStoredToken = (): void => {
  localStorage.removeItem(TOKEN_KEY);
};

async function apiRequest<T>(
  endpoint: string,
  options: RequestInit = {}
): Promise<T> {
  const token = getStoredToken();
  const headers = new Headers(options.headers || {});

  headers.set('Content-Type', 'application/json');
  if (token) {
    headers.set('Authorization', `Bearer ${token}`);
  }

  const response = await fetch(endpoint, {
    ...options,
    headers,
  });

  const data = await response.json().catch(() => ({
    success: false,
    message: 'Server returned an invalid JSON response',
  }));

  if (!response.ok) {
    throw new Error(data.message || `Request failed with status ${response.status}`);
  }

  return data;
}

export const api = {
  // Auth
  auth: {
    register: (userData: { name: string; email: string; password: string; course?: string }) =>
      apiRequest<{ success: boolean; token: string; user: User; message: string }>('/api/auth/register', {
        method: 'POST',
        body: JSON.stringify(userData),
      }),

    login: (credentials: { email: string; password: string }) =>
      apiRequest<{ success: boolean; token: string; user: User; message: string }>('/api/auth/login', {
        method: 'POST',
        body: JSON.stringify(credentials),
      }),

    logout: () =>
      apiRequest<{ success: boolean; message: string }>('/api/auth/logout', {
        method: 'POST',
      }),

    getCurrentUser: () =>
      apiRequest<{ success: boolean; user: User; databaseMode: string }>('/api/auth/me'),

    resetDemoData: () =>
      apiRequest<{ success: boolean; message: string }>('/api/auth/reset-demo', {
        method: 'POST',
      }),
  },

  // Subjects
  subjects: {
    getAll: () =>
      apiRequest<{ success: boolean; subjects: Subject[] }>('/api/subjects'),

    create: (data: { name: string; code?: string; description?: string; color?: string }) =>
      apiRequest<{ success: boolean; subject: Subject; message: string }>('/api/subjects', {
        method: 'POST',
        body: JSON.stringify(data),
      }),

    update: (id: number, data: { name: string; code?: string; description?: string; color?: string }) =>
      apiRequest<{ success: boolean; subject: Subject; message: string }>(`/api/subjects/${id}`, {
        method: 'PUT',
        body: JSON.stringify(data),
      }),

    delete: (id: number) =>
      apiRequest<{ success: boolean; message: string }>(`/api/subjects/${id}`, {
        method: 'DELETE',
      }),
  },

  // Tasks
  tasks: {
    getAll: (params?: {
      subjectId?: number;
      priority?: string;
      status?: string;
      search?: string;
      deadlineStatus?: string;
    }) => {
      const searchParams = new URLSearchParams();
      if (params?.subjectId) searchParams.append('subjectId', params.subjectId.toString());
      if (params?.priority) searchParams.append('priority', params.priority);
      if (params?.status) searchParams.append('status', params.status);
      if (params?.search) searchParams.append('search', params.search);
      if (params?.deadlineStatus) searchParams.append('deadlineStatus', params.deadlineStatus);

      const qs = searchParams.toString();
      return apiRequest<{ success: boolean; tasks: Task[]; count: number }>(
        `/api/tasks${qs ? `?${qs}` : ''}`
      );
    },

    getById: (id: number) =>
      apiRequest<{ success: boolean; task: Task }>(`/api/tasks/${id}`),

    create: (taskData: {
      subject_id: number;
      title: string;
      description?: string;
      priority: string;
      status: string;
      start_date: string;
      deadline: string;
      estimated_hours: number;
    }) =>
      apiRequest<{ success: boolean; task: Task; message: string }>('/api/tasks', {
        method: 'POST',
        body: JSON.stringify(taskData),
      }),

    update: (
      id: number,
      taskData: {
        subject_id: number;
        title: string;
        description?: string;
        priority: string;
        status: string;
        start_date: string;
        deadline: string;
        estimated_hours: number;
      }
    ) =>
      apiRequest<{ success: boolean; task: Task; message: string }>(`/api/tasks/${id}`, {
        method: 'PUT',
        body: JSON.stringify(taskData),
      }),

    updateStatus: (id: number, status: TaskStatus) =>
      apiRequest<{ success: boolean; task: Task; message: string }>(`/api/tasks/${id}/status`, {
        method: 'PATCH',
        body: JSON.stringify({ status }),
      }),

    delete: (id: number) =>
      apiRequest<{ success: boolean; message: string }>(`/api/tasks/${id}`, {
        method: 'DELETE',
      }),
  },

  // Statistics
  statistics: {
    get: () =>
      apiRequest<{ success: boolean; statistics: StatisticsData }>('/api/statistics'),
  },

  // AI Study Recommendations
  recommendations: {
    get: () =>
      apiRequest<{ success: boolean } & RecommendationData>('/api/recommendations'),
  },
};
