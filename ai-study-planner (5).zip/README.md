# Problem Statement 16 – AI Study Planner (Feature Set C)
### Bachelor of Computer Applications (BCA) – 3rd Year Academic Web Application

---

## 1. Project Title
**AI Study Planner** – Academic Semester Task Organizer & Intelligent Study Assistant.

---

## 2. Problem Statement
**Problem Statement 16 – AI Study Planner**  
College students, especially BCA students juggling programming languages, databases, web technologies, and networking courses, struggle to balance coursework modules, prioritize tight deadlines, track revision metrics, and construct efficient study schedules. This application solves that problem by providing an academic study planner with priority matrices, visual progress statistics, subject grouping, and AI recommendations.

---

## 3. Assigned Feature Set – Feature Set C
This project is built and verified strictly under **Feature Set C**, covering the mandatory 7-point feature set:
1. **Add study tasks**
2. **Edit study tasks**
3. **Delete study tasks**
4. **Subject-wise planning**
5. **Priority and deadlines**
6. **Progress statistics**
7. **Study recommendations**

---

## 4. Project Purpose
The primary purpose of **AI Study Planner** is to give university and college students a tool to:
- Organize academic study tasks by course subjects (e.g., Java, Python, DBMS, Web Development, Networks).
- Manage task priorities (`High`, `Medium`, `Low`) and track deadlines (`Overdue`, `Due Today`, `Due Tomorrow`, `Upcoming`).
- Calculate real-time completion statistics and visualize progress through responsive Donut and Bar charts.
- Receive personalized AI study advice powered by server-side Google Gemini 3.8 Flash, backed by an intelligent academic rule engine when offline.
- Guarantee strict student data isolation so each registered student only sees their own courses and tasks.

---

## 5. Features Implemented

### 1. User Authentication & Authorization (Security)
- Student registration with Full Name, Academic Email, Password, and Course.
- Secure password hashing using **bcrypt** (salt rounds = 10).
- Session security using **JSON Web Tokens (JWT)** passed via HTTP `Authorization: Bearer <token>` headers.
- Route protection middleware ensuring unauthorized requests receive HTTP 401.
- Strict data isolation: All SQL queries filter by `user_id = ?`.

### 2. Comprehensive Subject Management
- Full CRUD operations: Add, View, Edit, and Delete academic subjects.
- Subject metadata: Name, Course Code (e.g., `BCA-301`, `BCA-302`), Description, and Custom Color Identifiers.
- Cascade deletion: Deleting a subject automatically cascades to its associated study tasks via MySQL Foreign Key (`ON DELETE CASCADE`).

### 3. Study Task CRUD Management
- Add new tasks with Title, Description, Subject selector, Priority (`High`, `Medium`, `Low`), Status (`Pending`, `In Progress`, `Completed`), Start Date, Deadline, and Estimated Hours.
- Edit existing tasks seamlessly via responsive modal forms.
- Delete tasks with safe confirmation dialogs.
- One-click status cycling (`Pending` <-> `In Progress` <-> `Completed`) directly from dashboard and task lists.

### 4. Subject-Wise Planning
- Dedicated page grouping study tasks under their corresponding academic subject.
- Real-time subject completion percentage bar (e.g., *Java: 2/3 Completed (67%)*).
- Filter pills to focus on a single subject or expand all subjects simultaneously.
- Direct "+ Add Task" button tied to the specific subject.

### 5. Priority and Deadlines Matrix
- Visual columns for `High Priority`, `Medium Priority`, and `Low Priority`.
- Deadline classification:
  - **Overdue:** Past deadlines with warning indicators.
  - **Due Today:** Highlighted amber radar for immediate attention.
  - **Due Tomorrow:** Forward planning block.
  - **Upcoming:** Safe runway for future revision.
- Multi-field sorting by Deadline date, Priority weight, Subject name, and Estimated hours.

### 6. Visual Progress Statistics
- Real-time calculation of Total Tasks, Completed, In Progress, Pending, and Overdue tasks.
- Overall semester completion percentage.
- **Donut/Pie Chart:** Proportional distribution of task statuses.
- **Horizontal Bar Chart:** Comparative progress across each enrolled course subject.
- Study hours analytics: Total Hours vs. Completed Hours vs. Pending Hours.
- Comprehensive subject breakdown data table.

### 7. AI Study Recommendations
- Powered by **Google Gemini 3.8 Flash** (`@google/genai` TypeScript SDK) on the Node.js/Express server side.
- Evaluates the student's actual database workload:
  - Identifies approaching high-priority deadlines (e.g., *"You have a high-priority DBMS task due tomorrow. Consider studying DBMS for 2 hours today."*).
  - Highlights neglected subjects (e.g., *"You completed most Web Development tasks. You can now focus more time on DBMS."*).
  - Flags overdue topics requiring urgent intervention.
- Generates a **5-Day Suggested Revision Timetable** allocating pending tasks into balanced daily slots.
- **Academic Rule-Based Fallback:** If no Gemini API key is configured or network is limited, the built-in heuristic rule engine activates automatically without breaking the application or interrupting the viva demonstration!

### 8. Study Plan & Calendar Agenda
- Interactive 7-day quick date selector strip showing scheduled task counts per day.
- Detailed task breakdown for any selected date.
- "Due Today" and "Due Tomorrow" quick radar widgets.

---

## 6. Technologies Used

| Layer | Technology | Purpose |
| :--- | :--- | :--- |
| **Frontend Framework** | React.js (v19) | Modern component architecture, state management & reactive UI |
| **Styling & Design** | Tailwind CSS (v4) | Responsive, clean academic dashboard styling |
| **Icons** | Lucide React | High-clarity SVG UI icons |
| **Backend Framework** | Node.js + Express.js | High-performance REST API routing & controllers |
| **Authentication** | JWT (jsonwebtoken) & bcryptjs | Secure token issuance, password salting and hashing |
| **Database** | MySQL (XAMPP / MySQL Server) | Relational database with Foreign Keys & CASCADE rules |
| **AI Integration** | Google Gemini API (`@google/genai`) | Model `gemini-3.8-flash` for smart study recommendations |
| **Development Tooling** | Vite + tsx (TypeScript) | Fast bundling, type safety, unified full-stack server |

---

## 7. AI Tools Used
- **Google GenAI SDK (`@google/genai`)**: Official modern TypeScript SDK for server-side Gemini integration.
- **Model Selected**: `gemini-3.8-flash` (fastest latency, structured JSON schema response, highly effective for academic advice).
- **Telemetry Header**: `User-Agent: aistudio-build`.

---

## 8. Important AI Prompts / AI Usage
On the backend (`server/services/geminiService.ts`), the system sends a structured prompt containing the student's live database metrics:

```typescript
const prompt = `
You are an expert academic advisor and AI study coach for a 3rd-year Bachelor of Computer Applications (BCA) student named ${studentName}.
Analyze the student's actual current academic workload and produce tailored, actionable study advice.

Today's Date: ${todayStr}
Tomorrow's Date: ${tomorrowStr}

Student Workload Metrics:
- Total Tasks: ${tasks.length}
- Completed Tasks: ${completedTasks.length}
- Pending / In Progress Tasks: ${pendingTasks.length}
- Overdue Tasks: ${overdueTasks.length}
- Due Today Tasks: ${dueTodayTasks.length}
- Due Tomorrow Tasks: ${dueTomorrowTasks.length}
- High-Priority Pending Tasks: ${highPriorityPending.length}

Subject Breakdown:
${subjectSummary.map(s => `- ${s.name}: ${s.completed}/${s.total} completed, ${s.pending} pending, ${s.overdue} overdue, ${s.totalHours} hrs estimated`).join('\n')}

Generate:
1. Concise 2-sentence student diagnostic summary.
2. 4-5 high-impact recommendations (Urgent, Subject Focus, Schedule, Revision).
3. 5-day structured study timetable.
`;
```

The response is parsed and validated using a strictly typed `responseSchema` (`Type.OBJECT`, `Type.ARRAY`), ensuring valid JSON without code blocks or parsing errors.

---

## 9. Database Setup (MySQL)
The database structure is located in `database/schema.sql`.

### Relational Schema Design:
1. **`users` Table:**
   - `id` (INT, PRIMARY KEY, AUTO_INCREMENT)
   - `name` (VARCHAR 100)
   - `email` (VARCHAR 150, UNIQUE)
   - `password` (VARCHAR 255 - bcrypt hash)
   - `course` (VARCHAR 50)
   - `created_at` (TIMESTAMP)

2. **`subjects` Table:**
   - `id` (INT, PRIMARY KEY, AUTO_INCREMENT)
   - `user_id` (INT, FOREIGN KEY -> `users(id)` ON DELETE CASCADE)
   - `name` (VARCHAR 100)
   - `code` (VARCHAR 20)
   - `description` (TEXT)
   - `color` (VARCHAR 20)
   - `created_at` (TIMESTAMP)

3. **`tasks` Table:**
   - `id` (INT, PRIMARY KEY, AUTO_INCREMENT)
   - `user_id` (INT, FOREIGN KEY -> `users(id)` ON DELETE CASCADE)
   - `subject_id` (INT, FOREIGN KEY -> `subjects(id)` ON DELETE CASCADE)
   - `title` (VARCHAR 200)
   - `description` (TEXT)
   - `priority` (ENUM: `'High'`, `'Medium'`, `'Low'`)
   - `status` (ENUM: `'Pending'`, `'In Progress'`, `'Completed'`)
   - `start_date` (DATE)
   - `deadline` (DATE)
   - `estimated_hours` (DECIMAL 4,1)
   - `created_at` (TIMESTAMP)
   - `updated_at` (TIMESTAMP)

---

## 10. Installation Steps

### Prerequisites:
- Node.js (version 18 or higher installed on your computer).
- Git (optional, for version control).
- XAMPP / WampServer / MySQL Server (for local MySQL database).

### Step-by-Step Installation:
1. Clone or extract the project folder:
   ```bash
   cd ai-study-planner
   ```
2. Install all required frontend and backend dependencies:
   ```bash
   npm install
   ```

---

## 11. How to Run Frontend & Backend Together
This full-stack application uses an integrated architecture where Express serves both the REST API endpoints (`/api/*`) and mounts Vite dev middleware, running smoothly on port `3000`:

```bash
# Run inside the project root directory:
npm run dev
```

The application will start immediately at:  
👉 **http://localhost:3000**

---

## 12. How to Configure `.env`
Create a file named `.env` in the root folder (or copy from `.env.example`):

```env
# Gemini API Key (Optional: system provides automatic fallback if left empty)
GEMINI_API_KEY="YOUR_GEMINI_API_KEY_HERE"

# Server Port
PORT=3000

# JWT Secret Key for Session Encryption
JWT_SECRET="bca_ai_study_planner_jwt_secret_key_2026"

# MySQL Database Configuration (for XAMPP)
DB_HOST=localhost
DB_PORT=3306
DB_USER=root
DB_PASSWORD=
DB_NAME=ai_study_planner
```

---

## 13. How to Run with XAMPP / MySQL / phpMyAdmin

Follow these exact steps if testing with XAMPP:
1. **Open XAMPP Control Panel:**
   - Click **Start** next to **Apache**.
   - Click **Start** next to **MySQL**.
2. **Open phpMyAdmin:**
   - Open your browser and navigate to: `http://localhost/phpmyadmin/`
3. **Create the Database:**
   - Click on the **Databases** tab.
   - Enter `ai_study_planner` in the database name field.
   - Select collation `utf8mb4_unicode_ci` and click **Create**.
4. **Import `database/schema.sql`:**
   - Select the newly created `ai_study_planner` database from the left sidebar.
   - Click on the **Import** tab at the top.
   - Click **Choose File** and select `database/schema.sql` from this project folder.
   - Click **Import** (or **Go**) at the bottom.
   - You will see success messages confirming tables `users`, `subjects`, and `tasks` were created with pre-loaded sample BCA tasks.
5. **Verify `.env` Settings:**
   - Confirm `DB_HOST=localhost`, `DB_PORT=3306`, `DB_USER=root`, `DB_PASSWORD=`, `DB_NAME=ai_study_planner`.
6. **Start the Node.js Server:**
   ```bash
   npm run dev
   ```
   The server terminal will show:
   `[Database] Successfully connected to MySQL database: "ai_study_planner" on localhost:3306`

---

## 14. API Documentation

All protected routes require the header:  
`Authorization: Bearer <JWT_TOKEN>`

### Authentication Endpoints
- `POST /api/auth/register`
  - Body: `{ name, email, password, course }`
  - Response: `{ success: true, token, user }`
- `POST /api/auth/login`
  - Body: `{ email, password }`
  - Response: `{ success: true, token, user }`
- `GET /api/auth/me`
  - Response: Current student profile & active database mode.
- `POST /api/auth/reset-demo`
  - Response: `{ success: true, message: "Sample data reloaded" }`

### Subject Endpoints
- `GET /api/subjects` – Retrieve all subjects owned by logged-in student.
- `POST /api/subjects` – Add a new subject (`{ name, code, description, color }`).
- `PUT /api/subjects/:id` – Update an existing subject.
- `DELETE /api/subjects/:id` – Delete subject and cascade delete tasks.

### Task Endpoints
- `GET /api/tasks` – Retrieve study tasks (supports query filters: `?subjectId=1&priority=High&status=Pending&deadlineStatus=today&search=OOP`).
- `GET /api/tasks/:id` – Retrieve a specific task by ID.
- `POST /api/tasks` – Create new study task (`{ subject_id, title, description, priority, status, start_date, deadline, estimated_hours }`).
- `PUT /api/tasks/:id` – Update task details.
- `PATCH /api/tasks/:id/status` – Fast status toggle (`{ status: 'Completed' }`).
- `DELETE /api/tasks/:id` – Delete study task.

### Statistics & AI Advice Endpoints
- `GET /api/statistics` – Returns calculated counts, percentages, hours, priority breakdown, and subject completion arrays.
- `GET /api/recommendations` – Returns AI-generated advice, diagnostic assessment, and 5-day timetable.

---

## 15. Testing Feature Set C Requirements

During demonstration, follow these quick steps:

| Step | Feature | How to Demonstrate |
| :--- | :--- | :--- |
| **1** | **User Login** | Click "One-Click Examiner Demo Login" on the home page. Logs in as `rahul.sharma@bca.edu` with pre-loaded BCA syllabus data. |
| **2** | **Add Task** | Click the "+ Add Study Task" button on the Dashboard or Tasks tab. Enter title, select subject (e.g., *Java*), choose priority *High*, set deadline, and submit. |
| **3** | **Edit Task** | Click on any task title in the list or the pencil icon. Update estimated hours or title and save. |
| **4** | **Delete Task** | Click the trash icon next to a task. Confirm deletion in the pop-up modal. |
| **5** | **Subject-Wise Planning** | Navigate to the "Subject-Wise" tab. See tasks grouped by *Java Programming*, *DBMS*, *Web Development*, *Computer Networks*, and *Python*. Click filter pills. |
| **6** | **Priority & Deadlines** | Navigate to the "Priority & Deadlines" tab. Switch between "Group by Priority" (High, Medium, Low columns) and "Group by Deadline" (Overdue, Due Today, Due Tomorrow). |
| **7** | **Progress Statistics** | Navigate to "Statistics". View the Donut chart for status spread, Horizontal Bar chart for subject performance, and hours analysis table. |
| **8** | **AI Recommendations** | Navigate to "AI Advice". Review personalized recommendations generated from your actual pending tasks, and examine the suggested 5-day revision timetable. |

---

## 16. GitHub Upload Instructions

To upload this completed project to your GitHub account:

```bash
# 1. Initialize git in the root folder
git init

# 2. Stage all files (node_modules and .env are automatically excluded by .gitignore)
git add .

# 3. Create initial commit
git commit -m "feat: complete Problem Statement 16 AI Study Planner Feature Set C"

# 4. Rename default branch to main
git branch -M main

# 5. Link your GitHub repository (replace with your repo URL)
git remote add origin https://github.com/YOUR_USERNAME/ai-study-planner.git

# 6. Push to GitHub
git push -u origin main
```

---

## 17. Academic Viva Explanation (Simple BCA Terms)

### Q1: What is the architecture of this project?
**Answer:** The project follows the **Client-Server 3-Tier Architecture**:
1. **Presentation Layer (Frontend):** React.js with Tailwind CSS handles state, user forms, responsive tables, and SVG visual charts.
2. **Application / Business Logic Layer (Backend):** Node.js and Express.js handle REST API routes, password encryption with bcrypt, JWT token validation, and communication with the Gemini AI service.
3. **Data Layer (Database):** MySQL (or relational persistent storage) maintains normalized relational tables (`users`, `subjects`, `tasks`) with primary keys, foreign keys, and indexes.

### Q2: How does the AI Study Recommendation work?
**Answer:** The backend queries the logged-in student's live database records, calculates metrics (overdue count, tasks due tomorrow, pending hours per subject, high priority tasks), and passes this structured prompt to **Google Gemini 3.8 Flash** via `@google/genai`. If no API key is provided or the connection is offline, our built-in **academic rule-based fallback algorithm** evaluates the same parameters mathematically and returns structured, actionable recommendations.

### Q3: How is data security and user privacy enforced?
**Answer:**
- Passwords are never stored in plaintext; they are hashed with `bcryptjs` using a salt round of 10.
- When a user logs in, a signed **JSON Web Token (JWT)** is returned. The frontend stores this token and transmits it in the `Authorization: Bearer <token>` header for subsequent requests.
- Every SQL query on subjects and tasks explicitly contains `WHERE user_id = ?`, ensuring Student A cannot read or modify Student B's study records.

---

## 18. Project Folder Structure Walkthrough

```
ai-study-planner/
├── database/
│   └── schema.sql                # Complete MySQL DDL & DML script with sample BCA data
├── server/
│   ├── config/
│   │   └── database.ts           # MySQL connection pool + embedded relational persistent engine
│   ├── controllers/
│   │   ├── authController.ts     # User register, login, profile, and demo data reset
│   │   ├── subjectController.ts  # Subject CRUD logic with ownership verification
│   │   ├── taskController.ts     # Task CRUD, filters, and PATCH /status endpoint
│   │   ├── statisticsController.ts# Progress metrics, percentage & subject breakdown calculations
│   │   └── recommendationController.ts # Bridge to AI and rule-based advice engine
│   ├── middleware/
│   │   └── auth.ts               # JWT token verification middleware
│   ├── routes/
│   │   ├── authRoutes.ts         # /api/auth routes
│   │   ├── subjectRoutes.ts      # /api/subjects routes
│   │   ├── taskRoutes.ts         # /api/tasks routes
│   │   ├── statisticsRoutes.ts   # /api/statistics route
│   │   └── recommendationRoutes.ts # /api/recommendations route
│   └── services/
│       └── geminiService.ts      # Server-side Gemini 3.8 Flash SDK integration + fallback
├── src/
│   ├── components/
│   │   ├── Navbar.tsx            # Sticky navigation bar with mobile responsive menu
│   │   ├── StatCard.tsx          # Summary metric cards with custom icon badges
│   │   ├── Charts.tsx            # SVG Donut Chart, Horizontal Bar Chart & Progress Bar
│   │   ├── TaskModal.tsx         # Modal for adding & editing study tasks
│   │   ├── SubjectModal.tsx      # Modal for adding & editing course subjects
│   │   └── DeleteConfirmModal.tsx# Safe confirmation dialog for deletes
│   ├── context/
│   │   └── AuthContext.tsx       # Global React auth state, login/logout, and demo shortcuts
│   ├── pages/
│   │   ├── LandingPage.tsx       # Hero presentation page with feature highlights & demo login
│   │   ├── LoginPage.tsx         # Sign in page with credential validator & demo button
│   │   ├── RegisterPage.tsx      # Student registration form
│   │   ├── DashboardPage.tsx     # Central academic dashboard with stats, urgent deadlines & charts
│   │   ├── SubjectsPage.tsx      # Subject management cards with task counters
│   │   ├── TasksPage.tsx         # Complete task manager with search, filter, and sorting
│   │   ├── SubjectWisePage.tsx   # Subject-wise grouped task planner with progress bars
│   │   ├── PriorityDeadlinesPage.tsx # Priority columns & deadline radar
│   │   ├── StatisticsPage.tsx    # Visual analytics, Donut chart, Bar chart & breakdown table
│   │   ├── RecommendationsPage.tsx # AI recommendations & 5-day suggested timetable
│   │   ├── StudyPlanPage.tsx     # Calendar agenda & daily deadline selector
│   │   └── ProfilePage.tsx       # Student profile & demo database controls
│   ├── services/
│   │   └── api.ts                # Centralized fetch wrapper with Bearer token injection
│   ├── types/
│   │   └── index.ts              # TypeScript interfaces for User, Subject, Task, Stats, etc.
│   ├── App.tsx                   # Main application router and state coordination
│   ├── index.css                 # Global Tailwind CSS imports
│   └── main.tsx                  # React DOM root entry point
├── server.ts                     # Express server mounting REST APIs & Vite middlewares on port 3000
├── package.json                  # Scripts and dependencies
├── tsconfig.json                 # TypeScript compiler configuration
├── vite.config.ts                # Vite config with Tailwind CSS plugin
├── .env.example                  # Environment configuration template
└── README.md                     # Comprehensive academic documentation & viva guide
```
