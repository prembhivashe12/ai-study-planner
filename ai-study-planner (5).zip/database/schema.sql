-- ====================================================================
-- Problem Statement 16 – AI Study Planner (Feature Set C)
-- Academic Project for 3rd Year BCA
-- Database: MySQL (XAMPP / phpMyAdmin / MySQL Server)
-- ====================================================================

-- 1. Create Database if not exists
CREATE DATABASE IF NOT EXISTS `ai_study_planner` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `ai_study_planner`;

-- 2. Drop existing tables if re-importing (in correct foreign key order)
DROP TABLE IF EXISTS `tasks`;
DROP TABLE IF EXISTS `subjects`;
DROP TABLE IF EXISTS `users`;

-- 3. Users Table
-- Stores student account credentials and profile details
CREATE TABLE `users` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name` VARCHAR(100) NOT NULL,
  `email` VARCHAR(150) NOT NULL UNIQUE,
  `password` VARCHAR(255) NOT NULL,
  `course` VARCHAR(50) DEFAULT 'BCA 3rd Year',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 4. Subjects Table
-- Stores academic subjects owned by each logged-in user
CREATE TABLE `subjects` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT NOT NULL,
  `name` VARCHAR(100) NOT NULL,
  `code` VARCHAR(20) DEFAULT NULL,
  `description` TEXT DEFAULT NULL,
  `color` VARCHAR(20) DEFAULT '#3b82f6',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT `fk_subjects_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 5. Tasks Table
-- Stores study tasks linked to user and subject with priority and deadlines
CREATE TABLE `tasks` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT NOT NULL,
  `subject_id` INT NOT NULL,
  `title` VARCHAR(200) NOT NULL,
  `description` TEXT DEFAULT NULL,
  `priority` ENUM('High', 'Medium', 'Low') NOT NULL DEFAULT 'Medium',
  `status` ENUM('Pending', 'In Progress', 'Completed') NOT NULL DEFAULT 'Pending',
  `start_date` DATE NOT NULL,
  `deadline` DATE NOT NULL,
  `estimated_hours` DECIMAL(4,1) NOT NULL DEFAULT 2.0,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT `fk_tasks_user` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_tasks_subject` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 6. Indexes for Optimized Query Performance
CREATE INDEX `idx_tasks_user_status` ON `tasks` (`user_id`, `status`);
CREATE INDEX `idx_tasks_deadline` ON `tasks` (`deadline`);
CREATE INDEX `idx_tasks_priority` ON `tasks` (`priority`);
CREATE INDEX `idx_subjects_user` ON `subjects` (`user_id`);

-- ====================================================================
-- SAMPLE DEMO DATA (For Academic Demonstration & Viva Testing)
-- Default Student: rahul.sharma@bca.edu | Password: password123
-- Note: bcrypt hash for 'password123' is:
-- $2a$10$wN1r3wK3V.mJ9qLzU0bVeu3bY7E7W1Iu7I9V8kR2hC9JcKqR1yX4K
-- ====================================================================

INSERT INTO `users` (`id`, `name`, `email`, `password`, `course`, `created_at`) VALUES
(1, 'Rahul Sharma', 'rahul.sharma@bca.edu', '$2a$10$tZ2R8zIms9YIeDkE3q4E0.K9e1eK3N91/f0zQO2hD9L9vB2jFhJ5u', 'BCA 3rd Year', NOW());

INSERT INTO `subjects` (`id`, `user_id`, `name`, `code`, `description`, `color`, `created_at`) VALUES
(1, 1, 'Java Programming', 'BCA-301', 'Core Object-Oriented Programming, Multithreading, and Collections Framework', '#3b82f6', NOW()),
(2, 1, 'Database Management System', 'BCA-302', 'Relational database design, SQL queries, Normalization, and ACID Transactions', '#10b981', NOW()),
(3, 1, 'Web Development', 'BCA-303', 'HTML5, CSS3, JavaScript, React, and Backend REST APIs', '#8b5cf6', NOW()),
(4, 1, 'Computer Networks', 'BCA-304', 'OSI 7-Layer Architecture, TCP/IP, IP Addressing, and Subnetting', '#f59e0b', NOW()),
(5, 1, 'Python Programming', 'BCA-305', 'Data structures, NumPy, Pandas, and Scripting essentials', '#ef4444', NOW());

INSERT INTO `tasks` (`id`, `user_id`, `subject_id`, `title`, `description`, `priority`, `status`, `start_date`, `deadline`, `estimated_hours`, `created_at`) VALUES
(1, 1, 1, 'Implement OOP Inheritance and Polymorphism', 'Create class hierarchy for Employee Management System with method overriding.', 'High', 'Completed', CURDATE() - INTERVAL 5 DAY, CURDATE() - INTERVAL 2 DAY, 3.5, NOW()),
(2, 1, 1, 'Java Exception Handling & Custom Exceptions', 'Prepare laboratory program for user-defined InvalidAgeException with try-catch-finally.', 'Medium', 'In Progress', CURDATE() - INTERVAL 2 DAY, CURDATE() + INTERVAL 1 DAY, 2.0, NOW()),
(3, 1, 1, 'Collections Framework Practice (ArrayList & HashMap)', 'Solve 10 problems on HashMap and ArrayList sorting using Comparator.', 'Medium', 'Pending', CURDATE(), CURDATE() + INTERVAL 3 DAY, 4.0, NOW()),
(4, 1, 2, 'Database Normalization (1NF, 2NF, 3NF, BCNF)', 'Revise normalization rules with practical student-course anomaly examples for viva.', 'High', 'In Progress', CURDATE() - INTERVAL 1 DAY, CURDATE() + INTERVAL 1 DAY, 3.0, NOW()),
(5, 1, 2, 'Complex SQL Queries with JOINs and Subqueries', 'Write and test INNER, LEFT, RIGHT, and FULL OUTER JOINs with GROUP BY on sample tables.', 'High', 'Completed', CURDATE() - INTERVAL 6 DAY, CURDATE() - INTERVAL 3 DAY, 4.0, NOW()),
(6, 1, 2, 'ACID Properties and Transaction Concurrency', 'Read notes on Atomicity, Consistency, Isolation, Durability and lock protocols.', 'Low', 'Pending', CURDATE() + INTERVAL 1 DAY, CURDATE() + INTERVAL 5 DAY, 2.5, NOW()),
(7, 1, 3, 'Build Responsive Navigation and Flexbox Layout', 'Create mobile-friendly student portal landing screen with Tailwind CSS.', 'Medium', 'Completed', CURDATE() - INTERVAL 4 DAY, CURDATE() - INTERVAL 1 DAY, 3.0, NOW()),
(8, 1, 3, 'Create REST API with Express and Node.js', 'Implement CRUD routes for study tasks and connect to database with parameterized queries.', 'High', 'Completed', CURDATE() - INTERVAL 3 DAY, CURDATE(), 5.0, NOW()),
(9, 1, 3, 'Implement JWT Authentication & Protected Routes', 'Add token generation on login and auth middleware for protected endpoints.', 'High', 'In Progress', CURDATE() - INTERVAL 1 DAY, CURDATE() + INTERVAL 2 DAY, 4.0, NOW()),
(10, 1, 4, 'OSI vs TCP/IP Layer Comparison Chart', 'Draw and memorize functions and protocols for each of the 7 OSI layers.', 'High', 'Pending', CURDATE() - INTERVAL 3 DAY, CURDATE() - INTERVAL 1 DAY, 2.0, NOW()),
(11, 1, 4, 'Subnetting and IPv4 Addressing Calculation', 'Practice Class C subnet mask calculation with CIDR notation for 4 subnets.', 'Medium', 'Pending', CURDATE(), CURDATE() + INTERVAL 2 DAY, 3.0, NOW()),
(12, 1, 5, 'Python List Comprehensions & Lambdas', 'Practice one-line data transformations and filtering exercises.', 'Low', 'Completed', CURDATE() - INTERVAL 7 DAY, CURDATE() - INTERVAL 4 DAY, 2.0, NOW()),
(13, 1, 5, 'NumPy Array Operations and Reshaping', 'Solve assignment on 2D arrays, matrix multiplication, and slicing.', 'Medium', 'Pending', CURDATE() + INTERVAL 2 DAY, CURDATE() + INTERVAL 6 DAY, 3.5, NOW());
