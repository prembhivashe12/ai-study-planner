import express from 'express';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import authRoutes from './server/routes/authRoutes.js';
import subjectRoutes from './server/routes/subjectRoutes.js';
import taskRoutes from './server/routes/taskRoutes.js';
import statisticsRoutes from './server/routes/statisticsRoutes.js';
import recommendationRoutes from './server/routes/recommendationRoutes.js';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = Number(process.env.PORT) || 3000;

// Body parsing middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// API Health Check
app.get('/api/health', (_req, res) => {
  res.json({
    status: 'ok',
    project: 'AI Study Planner (Problem Statement 16 - Feature Set C)',
    course: 'BCA 3rd Year Academic Project',
    timestamp: new Date().toISOString(),
  });
});

// Download full project zip file for submission / local running
app.get('/api/download-zip', (_req, res) => {
  const zipPath = path.resolve(__dirname, 'ai-study-planner.zip');
  if (fs.existsSync(zipPath)) {
    res.download(zipPath, 'ai-study-planner.zip');
  } else {
    res.status(404).json({ success: false, message: 'Zip file not ready' });
  }
});

// REST API Routes
app.use('/api/auth', authRoutes);
app.use('/api/subjects', subjectRoutes);
app.use('/api/tasks', taskRoutes);
app.use('/api/statistics', statisticsRoutes);
app.use('/api/recommendations', recommendationRoutes);

// Global Error Handler for API routes
app.use('/api/*', (err: any, _req: express.Request, res: express.Response, _next: express.NextFunction) => {
  console.error('[API Error]:', err);
  res.status(500).json({
    success: false,
    message: err.message || 'Internal server error occurred.',
  });
});

// Dev server or Production static serving
async function startServer() {
  const isProd = process.env.NODE_ENV === 'production';

  if (!isProd) {
    // Mount Vite dev server middlewares
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    // Serve static files in production
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`====================================================`);
    console.log(` AI Study Planner - BCA 3rd Year Academic Project   `);
    console.log(` Server running on http://localhost:${PORT}        `);
    console.log(` Mode: ${isProd ? 'Production' : 'Development'}    `);
    console.log(`====================================================`);
  });
}

startServer().catch((err) => {
  console.error('Fatal Server Boot Error:', err);
  process.exit(1);
});
